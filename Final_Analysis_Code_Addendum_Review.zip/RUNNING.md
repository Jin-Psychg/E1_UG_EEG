# Environment and execution map

These instructions describe reproduction by a researcher with authorized input access. Packaging performed static checks only and did not start sampling, data preparation or recovery simulation.

## HDDM environment

The recorded environment is dockerHDDM (`hcp4715/hddm`), with HDDM 1.0.1RC, PyMC 2.3.8 and ArviZ 0.15.1 in the inspected run/validation records. The author-confirmed local image ID used for the final follow-ups was:

`sha256:29c574a5c7ff41eab3147b7907c461a08fdad527bb82a6c552d6e98536f6ccb4`

This is a local image ID, not a verified pullable registry digest. The historical `latest` tag does not pin an environment. The original image's `RepoDigests` and a complete package inventory still need to be exported from the author's Docker installation; the daemon was unavailable during packaging. Do not substitute a current image silently or claim bitwise replay. Model/configuration/data lineage checks in the code must remain enabled.

## Primary notebooks

Create a separate writable reproduction directory for each experiment. Copy its notebook and two configuration files there, and obtain its authorized `trials.csv`. Mount that experiment directory at `/home/jovyan/work` inside the verified dockerHDDM environment and open its notebook in Jupyter. Inspect the Step 1 input path before execution. Run the documented steps in order: preparation, configuration, estimation, PPC, architecture audit, inference and recovery. Step 2a generates configuration; do not manually change scientific settings to bypass a lineage error. Existing result directories should be preserved and reproduction should use separate output copies.

These notebooks evaluate the candidate architectures. Follow the manuscript's primary/secondary reporting allocation when reading outputs. They do not automatically implement the later targeted sensitivity and E2 iteration-19 update; those are mapped next.

## Follow-up runners and mounts

The original code uses explicit container paths. Supply the indicated approved run directories read-only and use a new writable directory at `/output`.

| Entry point | Required read-only mounts | Meaning |
|---|---|---|
| `run_authorized_refit_cleanup_fixed.py --job E1` | selected E1 run at `/e1` | Requires `results_hddm_final/models/hddm_va.hddm`, `hddm_data_unfair.csv` and original config; excludes the previously specified zero-accept model index |
| `run_authorized_refit_cleanup_fixed.py --job E2` | selected E2 run at `/e2` | Requires `results_hddm_final/recovery/recovery_va_posterior_iter19.hddm`; refits the saved synthetic dataset |
| `run_e2_sensitivity.py --job E2_sensitivity` | selected E2 run at `/e2`; original E2 zero-accept sensitivity directory at `/previous` | Requires saved empirical model, original config, original unfair data and previous sensitivity `analysis_data.csv` for input identity checks |
| `validation/E1/compare_posteriors.py` and E2 counterpart | selected experiment run at `/primary`; original sensitivity directory at `/previous`; final refit experiment directory at `/new` | Reads saved posteriors and source summaries; no fitting |
| `validation/E2_recovery/recompute_recovery.py` | selected E2 run at `/e2`; original refit batch directory at `/original` | Place the included `notebook_cell_13.py` in `/output`. Preserve the as-run runner at `/original/code/run_authorized_refit.py` because its hash is checked. Requires the exact accepted posterior and manifest under `/original/E2/` |

Both refit runners accept `--prepare-only` to perform their existing setup checks without sampling. This creates preparation outputs in the new `/output` directory. It is not evidence that a full fresh-environment run has been tested here. Refitting and posterior-validation inputs are controlled-access outputs and are intentionally not included in this public-code copy.

## R and EEG sensitivity setup

Restore the R environment from `environment/renv.lock` in a separate reproduction project. The as-run R scripts use the author's absolute `renv_lib`, `project_root`, `output_root`/`out`, and input paths. In a local reproduction copy, change only these filesystem roots to the approved UG input tree, restored R library and new output directory. The included `REPRODUCIBILITY.txt` files identify input files and checksums. Do not change formulae, factor coding, exclusion rules or diagnostic criteria.

For actor sensitivity, run the behavioral and ERP fitting scripts before their summary script; the interaction-contrast script produces the additional contrasts. For E2 threshold sensitivity, extract epoch features before fitting. The script's earlier nominal-window Part B is archival diagnostic work, not the reported S16 analysis. Aggregate CSV outputs are included so the reported table sources can be inspected without accessing participant-level data or running those scripts.

## Checks performed for this copy

All Python scripts were parsed without execution. Notebook cell sources were compared exactly to the selected originals after output removal. All included originals were hashed; code/configuration and aggregate reports otherwise remain byte-identical, except the separately labelled cleanup-fixed runner. A full R execution, fresh-container dependency check, numerical rerun and public-download test have not been performed. Release validation should distinguish these remaining delivery checks from the already completed scientific analyses.
