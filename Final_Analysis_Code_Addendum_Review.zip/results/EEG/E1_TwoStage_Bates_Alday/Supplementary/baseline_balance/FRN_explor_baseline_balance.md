# Baseline Balance Pre-Check: FRN_explor
Generated: 2026-08-22 08:50:27

## Purpose
Diagnostic test of whether mean baseline amplitude differs across
emotion x offer_type cells. PURE DIAGNOSTIC: does NOT gate or modify
the main analysis. The Alday baseline-as-covariate framework allows
baseline-condition interactions and tests them in the main model.

## Test
Model: Baseline_c ~ emotion * offer_type + (1 | participant_id)

Omnibus emotion:offer_type interaction: p = < .001

## Type III ANOVA
|Effect             |APA_Report                      |eta2_partial_95CI    |Sig |p_val |
|:------------------|:-------------------------------|:--------------------|:---|:-----|
|emotion            |F(4, 14148.48) = 2.95, p = .019 |0.001 [0.000, 0.002] |*   |.019  |
|offer_type         |F(1, 14148.01) = 0.84, p = .359 |0.000 [0.000, 0.001] |ns  |.359  |
|emotion:offer_type |F(4, 14148.06) = 0.67, p = .614 |0.000 [0.000, 0.001] |ns  |.614  |

## Cell means (microvolts)
|emotion |offer_type | mean_baseline| sd_baseline| n_trials|
|:-------|:----------|-------------:|-----------:|--------:|
|neu     |fair       |         0.183|       6.181|     1416|
|neu     |unfair     |         0.201|       5.465|     1424|
|aff     |fair       |        -0.047|       6.374|     1425|
|aff     |unfair     |         0.006|       6.028|     1416|
|dis     |fair       |        -0.195|       6.064|     1421|
|dis     |unfair     |        -0.332|       6.199|     1419|
|dom     |fair       |         0.069|       5.440|     1418|
|dom     |unfair     |         0.268|       6.017|     1418|
|enj     |fair       |        -0.246|       5.706|     1418|
|enj     |unfair     |         0.093|       7.061|     1412|

## Interpretation
If interaction p > 0.05: baseline is balanced across conditions; no
concern. If p < 0.05: condition-dependent baseline detected. The main
analysis tests Baseline_c:emotion and Baseline_c:offer_type
interactions in fit_stage1_bates Step 3 (LRT-based inclusion); a
significant baseline-condition coupling will be retained automatically
in the final model and reported in REPRODUCIBILITY.txt.
