# Baseline Balance Pre-Check: P3_explor
Generated: 2026-08-22 08:51:06

## Purpose
Diagnostic test of whether mean baseline amplitude differs across
emotion x offer_type cells. PURE DIAGNOSTIC: does NOT gate or modify
the main analysis. The Alday baseline-as-covariate framework allows
baseline-condition interactions and tests them in the main model.

## Test
Model: Baseline_c ~ emotion * offer_type + (1 | participant_id)

Omnibus emotion:offer_type interaction: p = < .001

## Type III ANOVA
|Effect             |APA_Report                      |eta2_partial_95CI    |Sig |p_val |
|:------------------|:-------------------------------|:--------------------|:---|:-----|
|emotion            |F(4, 14148.70) = 2.73, p = .028 |0.001 [0.000, 0.002] |*   |.028  |
|offer_type         |F(1, 14148.07) = 0.14, p = .705 |0.000 [0.000, 0.000] |ns  |.705  |
|emotion:offer_type |F(4, 14148.14) = 1.24, p = .293 |0.000 [0.000, 0.001] |ns  |.293  |

## Cell means (microvolts)
|emotion |offer_type | mean_baseline| sd_baseline| n_trials|
|:-------|:----------|-------------:|-----------:|--------:|
|neu     |fair       |        -0.096|       6.842|     1416|
|neu     |unfair     |         0.158|       5.931|     1424|
|aff     |fair       |        -0.141|       6.753|     1425|
|aff     |unfair     |        -0.145|       6.494|     1416|
|dis     |fair       |         0.022|       6.513|     1421|
|dis     |unfair     |        -0.370|       6.978|     1419|
|dom     |fair       |         0.190|       5.816|     1418|
|dom     |unfair     |         0.473|       6.727|     1418|
|enj     |fair       |        -0.079|       6.300|     1418|
|enj     |unfair     |        -0.012|       7.513|     1412|

## Interpretation
If interaction p > 0.05: baseline is balanced across conditions; no
concern. If p < 0.05: condition-dependent baseline detected. The main
analysis tests Baseline_c:emotion and Baseline_c:offer_type
interactions in fit_stage1_bates Step 3 (LRT-based inclusion); a
significant baseline-condition coupling will be retained automatically
in the final model and reported in REPRODUCIBILITY.txt.
