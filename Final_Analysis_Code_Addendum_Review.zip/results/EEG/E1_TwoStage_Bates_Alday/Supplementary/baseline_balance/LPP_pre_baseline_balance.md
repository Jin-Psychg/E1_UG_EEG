# Baseline Balance Pre-Check: LPP_pre
Generated: 2026-08-22 08:49:46

## Purpose
Diagnostic test of whether mean baseline amplitude differs across
emotion x offer_type cells. PURE DIAGNOSTIC: does NOT gate or modify
the main analysis. The Alday baseline-as-covariate framework allows
baseline-condition interactions and tests them in the main model.

## Test
Model: Baseline_c ~ emotion * offer_type + (1 | participant_id)

Omnibus emotion:offer_type interaction: p = < .001

## Type III ANOVA
|Effect             |APA_Report                      |eta2_partial_95CI    |Sig |p_val |
|:------------------|:-------------------------------|:--------------------|:---|:-----|
|emotion            |F(4, 14148.62) = 2.20, p = .067 |0.001 [0.000, 0.001] |.   |.067  |
|offer_type         |F(1, 14148.05) = 0.76, p = .384 |0.000 [0.000, 0.001] |ns  |.384  |
|emotion:offer_type |F(4, 14148.11) = 1.36, p = .245 |0.000 [0.000, 0.001] |ns  |.245  |

## Cell means (microvolts)
|emotion |offer_type | mean_baseline| sd_baseline| n_trials|
|:-------|:----------|-------------:|-----------:|--------:|
|neu     |fair       |        -0.101|       6.584|     1416|
|neu     |unfair     |         0.166|       5.674|     1424|
|aff     |fair       |        -0.145|       6.611|     1425|
|aff     |unfair     |        -0.055|       6.241|     1416|
|dis     |fair       |         0.030|       6.243|     1421|
|dis     |unfair     |        -0.345|       6.724|     1419|
|dom     |fair       |         0.139|       5.582|     1418|
|dom     |unfair     |         0.436|       6.507|     1418|
|enj     |fair       |        -0.155|       6.094|     1418|
|enj     |unfair     |         0.029|       7.238|     1412|

## Interpretation
If interaction p > 0.05: baseline is balanced across conditions; no
concern. If p < 0.05: condition-dependent baseline detected. The main
analysis tests Baseline_c:emotion and Baseline_c:offer_type
interactions in fit_stage1_bates Step 3 (LRT-based inclusion); a
significant baseline-condition coupling will be retained automatically
in the final model and reported in REPRODUCIBILITY.txt.
