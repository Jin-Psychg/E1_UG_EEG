# Baseline Balance Pre-Check: FRN_pre
Generated: 2026-08-22 08:49:14

## Purpose
Diagnostic test of whether mean baseline amplitude differs across
emotion x offer_type cells. PURE DIAGNOSTIC: does NOT gate or modify
the main analysis. The Alday baseline-as-covariate framework allows
baseline-condition interactions and tests them in the main model.

## Test
Model: Baseline_c ~ emotion * offer_type + (1 | participant_id)

Omnibus emotion:offer_type interaction: p = < .001

## Type III ANOVA
|Effect             |APA_Report                      |eta2_partial_95CI    |Sig |p_val |
|:------------------|:-------------------------------|:--------------------|:---|:-----|
|emotion            |F(4, 14148.54) = 3.41, p = .009 |0.001 [0.000, 0.002] |**  |.009  |
|offer_type         |F(1, 14148.03) = 1.10, p = .295 |0.000 [0.000, 0.001] |ns  |.295  |
|emotion:offer_type |F(4, 14148.08) = 0.49, p = .743 |0.000 [0.000, 0.000] |ns  |.743  |

## Cell means (microvolts)
|emotion |offer_type | mean_baseline| sd_baseline| n_trials|
|:-------|:----------|-------------:|-----------:|--------:|
|neu     |fair       |         0.174|       5.432|     1416|
|neu     |unfair     |         0.226|       4.862|     1424|
|aff     |fair       |        -0.014|       5.740|     1425|
|aff     |unfair     |         0.002|       5.374|     1416|
|dis     |fair       |        -0.234|       5.326|     1421|
|dis     |unfair     |        -0.284|       5.384|     1419|
|dom     |fair       |         0.057|       4.801|     1418|
|dom     |unfair     |         0.208|       5.294|     1418|
|enj     |fair       |        -0.220|       5.081|     1418|
|enj     |unfair     |         0.086|       6.341|     1412|

## Interpretation
If interaction p > 0.05: baseline is balanced across conditions; no
concern. If p < 0.05: condition-dependent baseline detected. The main
analysis tests Baseline_c:emotion and Baseline_c:offer_type
interactions in fit_stage1_bates Step 3 (LRT-based inclusion); a
significant baseline-condition coupling will be retained automatically
in the final model and reported in REPRODUCIBILITY.txt.
