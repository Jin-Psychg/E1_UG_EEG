# Methods Paragraph (Behavioral Analyses, Stage Integrative)

Integrative cross-experiment analysis (E1 + E2 pooled)

Generated: 2026-08-22 09:00:53

## Statistical Analysis

Behavioral data were analyzed using mixed-effects models in R (4.3.3) with the
lme4 (1.1.38) and lmerTest (3.1.3) packages, with binomial models fitted via glmmTMB
(1.1.14). Categorical predictors used sum-to-zero contrasts (R option contr.sum)
to support valid Type III tests in the presence of interactions (Schad,
Vasishth, Hohenstein, & Kliegl, 2020). Trials were excluded if the
participant did not respond (reaction = 0), if response time fell outside
300-3000 ms, or if the offer was the medium-fairness filler (Offers_Other = 7).
Response time was log-transformed for the linear models to stabilize variance
and better meet the assumption of normally distributed residuals. For each
fitted linear model, residual assumptions were assessed via residual skewness
and excess kurtosis, a homoscedasticity index (the Spearman correlation between
the absolute residual and the fitted value), and Q-Q and residual-vs-fitted
plots (assumptions_<analysis>.md and .pdf in each output directory). At the
single-trial sample sizes used here, formal normality tests are over-powered
and were therefore not used for this purpose.

Models fitted in this stage:

All three analyses below are 3-way mixed-effects models with Experiment (E1
sequential vs E2 simultaneous) as a between-subjects factor. Participant ids
were uniquified across experiments via the prefix '<Exp>_' to prevent any
collision between E1 and E2 numeric ids.

1. **Rejection rate (GLMM_rejection):** binomial mixed-effects model on
   reject_binary with predictors Experiment x emotion x offer type (full
   3-way interaction).

2. **Response time, main analysis (LMM_RT_main):** linear mixed-effects model
   on log RT with predictors Experiment x emotion x offer type (full 3-way
   interaction). Reaction not included (collider; Rohrer, 2018).

3. **Response time, unfair-only (LMM_RT_unfair):** linear mixed-effects model
   on log RT restricted to unfair trials, with Experiment x emotion x
   reaction.

Post-hoc decomposition for 3-way models follows the Maxwell-Delaney layered
strategy: when the 3-way interaction is significant, simple effects are
decomposed per Experiment. When the 3-way is not significant, lower-order
2-way interactions are evaluated independently and main effects reported
only for factors NOT participating in any significant 2-way interaction.

### Random-effects structure

Random-effects structures were selected following the parsimonious-Bates
protocol (Bates, Kliegl, Vasishth, & Baayen, 2015; Matuschek, Kliegl,
Vasishth, Baayen, & Bates, 2017). Starting from the design-justified maximal
model (random intercepts and slopes for within-subject factors by
participant), zero-correlation parameter (ZCP) models were fitted by
representing factor slopes as separate sum-contrast columns, so that the ZCP
terms were genuinely diagonal rather than correlated dummy-level blocks.
All contrast columns belonging to one factor were grouped as one buildmer
selection block through the documented buildmer terms-list interface.
Unsupported variance-component blocks were removed via likelihood-ratio tests
with elimination alpha = 0.20 using the buildmer package. Correlation
parameters between surviving slopes were tested in a final step.
Random-effects dimensionality was diagnosed via rePCA (Bates et al., 2015).
Because this selection is data-driven and applied to each dataset independently,
the retained structure can differ across experiments; such differences reflect
genuine between-experiment differences in the supported variance components and
are reported as-is. Cross-experiment inference is therefore based on the
Integrative model (the Experiment x condition interaction terms), not on
comparing the significance of separately fitted per-experiment models.

For the Integrative analysis, Experiment was modeled as a between-subjects
factor (each participant belongs to exactly one experiment). Random slopes
for Experiment by participant are unidentifiable by design and were
therefore not included. Participant ids were prefixed by the experiment
label ("E1_", "E2_") to guarantee uniqueness across experiments.

Stimulus identity was counterbalanced across participants via a Latin-square
design and was not modeled as a separate random effect (cf. Westfall, Kenny,
& Judd, 2014).

### Inferential strategy

For linear mixed models, fixed-effect inference used a Type III F-test with
denominator degrees of freedom approximated via a cascading method
preference: Satterthwaite (Kuznetsova, Brockhoff, & Christensen, 2017;
Luke, 2017) was attempted first; on numerical failure, Kenward-Roger
(Kenward & Roger, 1997; via the pbkrtest backend) was attempted; Wald
chi-square (car::Anova) was used only as a final fallback. The method
actually used per analysis is reported in the supplementary REPRODUCIBILITY
log. For the binomial model, Wald chi-square tests were used because
Satterthwaite and Kenward-Roger are not defined for non-Gaussian
likelihoods (the residual variance term they require does not exist in
binomial likelihoods, where Var(y) is determined by the mean structure as
p(1-p)). Binomial models were fitted by maximum likelihood with the Laplace
approximation (glmmTMB; Brooks et al., 2017), and fixed effects were tested with
Wald chi-square tests (Bolker et al., 2009). Because the responses are binary
(Bernoulli, 0/1), observation-level overdispersion is not identifiable -- the
variance p(1-p) is fixed entirely by the mean -- so no scale or dispersion
parameter was estimated.

Post-hoc contrasts were computed using the emmeans package (Lenth, 2024)
with asymptotic standard errors and false-discovery-rate (FDR) correction
within each effect family.

### Effect-size reporting

For Gaussian models, partial eta-squared with 95% confidence intervals are
reported alongside F-tests (effectsize::eta_squared). For the binomial
model, partial eta-squared is not defined; odds ratios with 95% CIs are
reported for fixed-effect contrasts, and marginal R-squared (Nakagawa-
Schielzeth, 2013) together with the Tjur (2009) coefficient of discrimination
are reported for overall model fit (the conditional R-squared is reported
additionally when the random-effect variance is extractable). For log-RT
contrasts, percent RT change is reported as (exp(b) - 1) x 100.

### Post-hoc gating

For 2-way analyses (single-experiment stages E1 and E2), simple-effect
decompositions of the emotion x offer_type (or emotion x reaction)
interaction were performed only when the omnibus interaction p < 0.05.
Effects with 0.05 <= p < 0.10 were computed but reported only in
supplementary materials, never as confirmatory evidence.

For 3-way analyses (Integrative stage), decomposition was layered:
(a) if the 3-way Experiment x emotion x within-factor interaction was
significant (p < 0.05), simple effects were decomposed per Experiment;
(b) if 0.05 <= 3-way p < 0.10, the same decomposition was performed but
written to Supplementary; (c) if the 3-way was not significant, each 2-way
interaction was evaluated independently and main effects reported only for
factors not participating in any significant 2-way interaction.

## Sample

35694 trials from 60 unique participants entered the main analyses in this stage;
the unfair-only stratum included 17838 trials.


