Table: Type III ANOVA (Wald_chi_square_GLMM), GLMM_rejection.

|Effect                 |APA_Report               |Sig |p_val  |
|:----------------------|:------------------------|:---|:------|
|(Intercept)            |χ²(1) = 17.91, p < .001  |*** |< .001 |
|Exp                    |χ²(1) = 3.24, p = .072   |.   |.072   |
|emotion                |χ²(4) = 139.78, p < .001 |*** |< .001 |
|offer_type             |χ²(1) = 344.78, p < .001 |*** |< .001 |
|Exp:emotion            |χ²(4) = 7.83, p = .098   |.   |.098   |
|Exp:offer_type         |χ²(1) = 0.00, p = .959   |ns  |.959   |
|emotion:offer_type     |χ²(4) = 13.81, p = .008  |**  |.008   |
|Exp:emotion:offer_type |χ²(4) = 11.85, p = .018  |*   |.018   |
