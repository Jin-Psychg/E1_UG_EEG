# Manuscript and supplement source map

All paths below are relative to this addendum unless described as controlled-access inputs. Selected aggregate reports are included without recalculation.

| Manuscript component | Code / report location | Input or scope |
|---|---|---|
| HDDM Methods, Figures 3/8, Tables S8–S11 | `hDDM__details/hDDM_E1/Final_vazt-Unfair_Grouplevel_InformativePr_E1.ipynb`; corresponding E2 notebook; each experiment's configuration | Separate selected E1/E2 runs; controlled-access `trials.csv` |
| Primary versus secondary group-level estimates, S11 | Each experiment's `results_hddm_final/audit/focal_parameter_audit_{va,vaz}.csv` | Aggregate parameter reports; posterior draws excluded |
| E1/E2 recovery, S17 | Each experiment's `results_hddm_final/tables_supp/recovery_aggregate_summary_va_{posterior,prior}.csv` | E2 posterior aggregate includes the validated iteration-19 replacement; the broader/prior-labelled track is unchanged |
| E2 recovery replacement | `hddm_followup/refits/as_run/run_authorized_refit.py --job E2`; `hddm_followup/validation/E2_recovery/recompute_recovery.py` | Uses the same saved synthetic iteration, not newly generated recovery data; receipt included |
| Zero-accept sensitivity, S19 | E1: `hddm_followup/refits/as_run/run_authorized_refit.py --job E1`; E2: `hddm_followup/refits/run_e2_sensitivity.py --job E2_sensitivity` | Final primary-precision fits; `hddm_followup/validation/{E1,E2}/` contains comparison code and aggregate contrast/diagnostic reports |
| Actor-intercept sensitivity, S14/S15 | `sensitivity/actor-random-intercept_2026-08-23/` | Existing canonical behavior/EEG model formulae and trial files; final intercept sensitivity is distinct from unsuccessful slope extensions |
| E2 artifact-threshold sensitivity, S16 | `sensitivity/erp-registered-E2_2026-08-23/`, Part A | Requires original epochs, canonical trial table and saved model specifications; participant-level extracted features excluded |
| Baseline balance, M7 | `results/EEG/E1_TwoStage_Bates_Alday/Supplementary/baseline_balance/` | Four aggregate baseline reports |
| Choice comparisons, S15 | `results/Behavior/{E1,E2}_TwoStage_Bates/GLMM_Rejection/posthoc_Main_Effect_Emotion.md` and actor-sensitivity interaction report | Existing aggregate outputs |
| Pooled behavior, S20 | `results/Behavior/Integrative_TwoStage_Bates/` | Supplementary secondary analyses; no new main-text pooled interpretation |
| RT comparisons, S21 | `results/Behavior/{E1,E2}_TwoStage_Bates/LMM_RT_main/posthoc_Simple_emotion_by_offer_type.md` | Existing aggregate outputs |
| E2 ERP expression comparisons, S22 | `results/EEG/E2_TwoStage_Bates_Alday/Stage1_TrialLevel/{FRN_pre,LPP_pre}/posthoc_Main_Effect_Emotion.md` | Harmonized, non-preregistered E2 windows |

Filenames in S18 such as `trials.csv`, `hddm_data_unfair.csv` and participant-level PPC reports designate controlled-access analysis inputs/outputs, not files made public by this addendum. The original UG repository supplies the broader behavioral/EEG preprocessing pipeline and study materials; this is an addendum rather than a full replacement archive.
