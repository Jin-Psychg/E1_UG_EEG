# Final-analysis code addendum

This review copy supplies the final HDDM notebooks, configurations, follow-up code and selected aggregate reports used by the accompanying manuscript and supplement. It supplements the existing UG analysis repository. It has not yet been published or tested in a fresh container.

Start with [SOURCE_MAP.md](SOURCE_MAP.md) for manuscript-to-file mapping and [RUNNING.md](RUNNING.md) for environments, input placement and execution order. [manifest.json](manifest.json) records source and delivered SHA-256 hashes. The notebooks retain every code and Markdown cell; execution outputs, execution counts and incidental notebook metadata were removed. No analysis was rerun to make this package.

## What is included

- `hDDM__details/hDDM_E1/` and `hDDM__details/hDDM_E2/`: the selected final notebooks and their generated configurations. These are the actual selected analysis implementations, replacing the old repository's reference-only HDDM route.
- `hddm_followup/`: the final zero-accept sensitivity runners, the targeted E2 recovery refit route, independent saved-posterior validation code and group-level comparison reports.
- `sensitivity/`: actor-intercept and E2 artifact-threshold sensitivity scripts and aggregate reports.
- `results/`: selected aggregate source reports cited in the supplement.
- `environment/renv.lock`: the live UG project's R environment lockfile.

The experiment notebooks have independent input and output directories. Their filenames refer to the candidate model space; they do not identify the manuscript's primary reporting model. The manuscript reports `va` as primary and displays `vaz` as secondary; E2's minimum-DIC model remains `vaz`. Historical comments or diagnostic flags in code do not supersede that reporting decision. PPC discrepancies are described continuously, not as a universal manuscript pass/fail test.

## Data access

Participant-level trial files, EEG, participant mappings, saved model objects, posterior draws, facial stimuli and notebooks with execution outputs are excluded. They follow the manuscript's controlled-access arrangements. Full reproduction requires the approved input files or saved outputs specified in RUNNING.md. This package does not claim that code alone reproduces the empirical results without those inputs.

## Completed analyses and historical process errors

Both final zero-accept sensitivity analyses and E2 recovery validation were completed before this package was assembled. The E1 sensitivity and E2 recovery processes saved their posterior draws and assessments, then raised an exception while attempting `InferenceData.close()`. Independent validation checked the saved results. A process exit code from that cleanup error is not the inferential status of the saved posterior.

`hddm_followup/refits/as_run/run_authorized_refit.py` preserves that exact implementation for provenance. The adjacent `run_authorized_refit_cleanup_fixed.py` changes only the post-export cleanup to close each contained xarray dataset. This new copy passed a syntax check; it has not been used for a new fit. The final E2 sensitivity runner already contains the earlier tested cleanup correction. Do not rerun a completed analysis merely to replace historical exit-status records.

The E2 threshold-sensitivity script also contains an earlier Part B with nominal-window diagnostic analyses, including a provisional N2 ROI comment. Those diagnostics are not reported as the manuscript's formal preregistered-window analyses and are not an unfinished manuscript task. Table S16 uses Part A's artifact-threshold comparison. The exact source script is retained so its scope is visible.

## Before public release

1. Verify the original Docker image's registry digest and obtain an environment package inventory. The recorded local image ID is in RUNNING.md; the Docker daemon was unavailable during packaging, so its registry digest was not guessed.
2. Add this directory's contents to the public artifact as a versioned final-analysis release. Preserve any existing files under explicit versioning when paths overlap. Update the old `hDDMdetails/README.md` to link to `hDDM__details/` and this README, and label old notebooks as superseded reference copies.
3. Confirm the public release exposes both final notebooks, their configurations, this source map and the follow-up scripts. Confirm that controlled-access inputs and author-only records were not added.

No new license is assigned here. Retain the parent project's license and any applicable third-party notices. The author-facing source-location ledger is kept outside this package.
