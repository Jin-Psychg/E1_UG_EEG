"""Run versioned, author-approved refits without writing to selected source runs."""
from pathlib import Path
import argparse
import gc
import hashlib
import json
import os
import random
import sys
import time
import numpy as np
import pandas as pd
import arviz as az
import hddm

OUT = Path('/output')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_saved_state(path):
    # Read the original analysis frame; do not recreate the old model's nodes/DB.
    original = hddm.HDDMRegressor.__setstate__
    hddm.HDDMRegressor.__setstate__ = lambda self, state: self.__dict__.update(state)
    try:
        return hddm.load(path)
    finally:
        hddm.HDDMRegressor.__setstate__ = original

def metrics_of(idata, limits):
    summary = az.summary(idata, hdi_prob=0.95, round_to=6)
    names = [p for p in summary.index if '_subj.' not in p and not p.endswith('_std')
             and (p.endswith('_Intercept') or "C(emotion, Treatment('neu'))" in p)]
    if len(names) != 12:
        raise ValueError(f'Expected 12 focal parameters, got {names}')
    cols = ['r_hat', 'ess_bulk', 'ess_tail']
    if not np.isfinite(summary[cols].to_numpy()).all():
        raise ValueError('Non-finite posterior diagnostics')
    focal, nuisance = summary.loc[names], summary.drop(index=names)
    metrics = {'f_rhat':float(focal.r_hat.max()), 'f_bulk':float(focal.ess_bulk.min()),
               'f_tail':float(focal.ess_tail.min()), 'n_rhat':float(nuisance.r_hat.max()),
               'n_bulk':float(nuisance.ess_bulk.min()), 'n_tail':float(nuisance.ess_tail.min())}
    passed = (metrics['f_rhat'] <= limits['f_rhat'] and metrics['f_bulk'] >= limits['f_bulk']
              and metrics['f_tail'] >= limits['f_tail'] and metrics['n_rhat'] <= limits['n_rhat']
              and metrics['n_bulk'] >= limits['n_bulk'])
    return summary, metrics, bool(passed)

def run(job, prepare_only):
    base = Path('/e2')
    rel = 'models/hddm_va.hddm'
    source = base / 'results_hddm_final' / rel
    sys.path.insert(0, str(base))
    saved = read_saved_state(source)
    frame = saved.data.copy(deep=True)
    if frame[['subj_idx', 'emotion', 'rt', 'response']].isna().any().any():
        raise ValueError('Missing input values')
    if set(frame.response.unique()) != {0, 1} or not np.isfinite(frame.rt).all():
        raise ValueError('Unexpected response coding or RT')
    # Saved HDDM frames already encode lower-boundary responses with negative RT.
    if not ((frame.rt > 0) == (frame.response == 1)).all() or (frame.rt == 0).any():
        raise ValueError('Saved signed RT does not match response coding')
    excluded = []
    if job == 'E2_sensitivity':
        original_input = pd.read_csv(base/'hddm_data_unfair.csv', dtype={'subj_idx':str})
        comparison = frame.copy(deep=True)
        comparison['rt'] = comparison.rt.abs()
        pd.testing.assert_frame_equal(comparison.reset_index(drop=True), original_input,
                                      check_exact=False, rtol=1e-12, atol=1e-12)
        counts = frame.groupby('subj_idx').response.sum()
        excluded = counts[counts == 0].index.tolist()
        if sorted(map(str, excluded)) != ['1', '22']:
            raise ValueError(f'Unexpected excluded IDs: {excluded}')
        data = frame.loc[~frame.subj_idx.isin(excluded)].copy()
        pd.testing.assert_frame_equal(data.reset_index(drop=True),
                                      frame.loc[~frame.subj_idx.isin(excluded)].reset_index(drop=True))
        prior_data = pd.read_csv('/previous/analysis_data.csv', dtype={'subj_idx':str})
        prior_comparison = data.copy(deep=True)
        prior_comparison['rt'] = prior_comparison.rt.abs()
        pd.testing.assert_frame_equal(prior_comparison.reset_index(drop=True), prior_data,
                                      check_exact=False, rtol=1e-12, atol=1e-12)
        assert len(data) == 10018 and data.subj_idx.nunique() == 28
        config_path = base / 'hddm_config_values.json'
        config = json.loads(config_path.read_text())
        protocol = config['mcmc_protocols']['va']
        assert (protocol['n_samples'], protocol['burn'], protocol['thin'], protocol['max_samples'], config['n_chains']) == (8000, 2000, 2, 18000, 4)
        schedule, burn, thin = [8000, 12000, 18000], protocol['burn'], protocol['thin']
        limits = dict(f_rhat=config['rhat_focal'], f_bulk=config['ess_bulk_focal'],
                      f_tail=config['ess_tail_focal'], n_rhat=config['rhat_nuisance'],
                      n_bulk=config['ess_bulk_nuisance'])
        assert limits == dict(f_rhat=1.01, f_bulk=1000, f_tail=500, n_rhat=1.05, n_bulk=400)
    else:
        raise ValueError('Only the authorized E2 sensitivity job is supported')
    formulas = [d['outcome'] + ' ~' + d['model'] for d in saved.model_descrs]
    kwargs = dict(include=['v','a','t','z'], is_group_model=True, group_only_regressors=True,
                  keep_regressor_trace=False, informative=bool(saved.is_informative),
                  p_outlier=float(saved.p_outlier))
    result_dir = OUT / job
    if not prepare_only and result_dir.exists():
        raise FileExistsError(f'Refusing to overwrite {result_dir}')
    model = hddm.HDDMRegressor(data, formulas, **kwargs)
    for actual, expected in zip(model.model_descrs, saved.model_descrs):
        assert actual['outcome'] == expected['outcome']
        assert actual['params'] == expected['params']
        grid = np.array([.1,.5,.9])
        np.testing.assert_array_equal(actual['link_func'](grid), expected['link_func'](grid))
    assert set(model.group_only_nodes) == set(saved.group_only_nodes)
    assert model.wiener_params == saved.wiener_params
    assert model.default_intervars == saved.default_intervars
    pd.testing.assert_frame_equal(model.data, data)
    manifest = {'job':job, 'source_model':str(source), 'source_sha256':digest(source),
                'source_rows':len(frame), 'analysis_rows':len(data),
                'participants':int(data.subj_idx.nunique()), 'excluded_ids':list(map(str,excluded)),
                'formulas':formulas, 'kwargs':kwargs, 'schedule':schedule, 'burn':burn, 'thin':thin,
                'chains':4, 'base_seed':2508, 'criteria':limits,
                'data_policy':'E2 saved empirical frame minus zero-accept model indices 1 and 22; matches both canonical input and prior sensitivity rows/order.',
                'config_sha256':digest(config_path), 'previous_data_sha256':digest(Path('/previous/analysis_data.csv')),
                'seed_limit':'Base NumPy/Python seeds recorded; library parallel-worker RNG behavior retained, not a claim of bitwise reproducibility',
                'status':'PREFLIGHT_PASSED'}
    if not prepare_only:
        assert manifest == json.loads((OUT / f'{job}_preflight.json').read_text()), 'Preflight source/config/model identity changed'
    if prepare_only:
        (OUT / f'{job}_preflight.json').write_text(json.dumps(manifest, indent=2))
        print(json.dumps(manifest, indent=2), flush=True)
        return
    result_dir.mkdir()
    data.to_csv(result_dir/'analysis_data.csv', index=False)
    manifest['analysis_csv_sha256'] = digest(result_dir/'analysis_data.csv')
    (result_dir/'manifest.json').write_text(json.dumps(manifest, indent=2))
    del model, saved, frame
    gc.collect()
    attempts = []
    for number, samples in enumerate(schedule, 1):
        attempt = result_dir / f'attempt_{number}_{samples}'
        attempt.mkdir()
        os.chdir(attempt)
        np.random.seed(2508); random.seed(2508)
        started = time.time()
        status = {'status':'RUNNING', 'samples':samples, 'started_unix':started, 'job':job}
        (result_dir/'status.json').write_text(json.dumps(status, indent=2))
        print(f'{job}: starting {samples} samples, burn={burn}, thin={thin}, four chains', flush=True)
        model = hddm.HDDMRegressor(data, formulas, **kwargs)
        idata = model.sample(samples, burn=burn, thin=thin, chains=4,
                             return_infdata=True, loglike=False, ppc=False,
                             save_name=str(attempt/'refit'))
        if not isinstance(idata, az.InferenceData):
            raise TypeError('Sampler did not return InferenceData')
        expected_draws = (samples-burn)//thin
        assert idata.posterior.sizes['chain'] == 4, 'Library dropped a chain'
        assert idata.posterior.sizes['draw'] == expected_draws, 'Unexpected or stale posterior length'
        path = attempt/'verified_posterior.nc'
        idata.to_netcdf(path)
        disk = az.from_netcdf(path)
        assert disk.posterior.equals(idata.posterior), 'Export round-trip mismatch'
        summary, metrics, passed = metrics_of(disk, limits)
        summary.to_csv(attempt/'posterior_summary.csv')
        status = dict(status, status='DIAGNOSTICS_PASSED' if passed else 'CRITERIA_NOT_MET',
                      metrics=metrics, passed=passed, posterior=str(path),
                      sha256=digest(path), elapsed_seconds=time.time()-started)
        (attempt/'assessment.json').write_text(json.dumps(status, indent=2))
        (result_dir/'status.json').write_text(json.dumps(status, indent=2))
        attempts.append(status)
        print(json.dumps(status), flush=True)
        for group in disk.groups():
            getattr(disk, group).close()
        del disk, idata, model, summary
        gc.collect()
        if passed:
            break
    completion = {'job':job, 'passed':passed, 'attempts':attempts, 'status':'COMPLETED',
                  'reporting_status':'Pending source-based contrast/recovery comparison; not automatically adopted'}
    (result_dir/'completion.json').write_text(json.dumps(completion, indent=2))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', choices=['E2_sensitivity'], required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    run(args.job, args.prepare_only)
