class MetricsOnly:

    @staticmethod
    def _apply_link_and_clip(param_family: str, lp_val: float) -> float:
        """
        Applies the HDDMRegressor inverse links and enforces bounds.
        Identity for v, a and t; logit for z.
        v: identity, clipped to [-8, 8]
        a: identity, clipped to [0.2, 4.0]
        t: identity, clipped to [0.05, 2.0]
        z: expit, clipped to [0.05, 0.95]
        """
        if param_family == 'v':
            return float(np.clip(lp_val, -8.0, 8.0))
        elif param_family == 'a':
            return float(np.clip(lp_val, 0.2, 4.0))
        elif param_family == 't':
            return float(np.clip(lp_val, 0.05, 2.0))
        elif param_family == 'z':
            return float(np.clip(expit(lp_val), 0.05, 0.95))
        return lp_val

    def compute_iteration_metrics(self, group_truth: Dict[str, float], summary_df: pd.DataFrame, iteration: int, mode: str, converged: bool, max_rhat: float, metrics: Dict[str, float]) -> List[Dict]:
        """
        Computes per-parameter recovery metrics for a single
        iteration: Bias, Squared Error, Coverage, HDI Width.

        Ground-truth and recovered values are compared on the physical
        parameter scale. For v/a/t the generative and reported scales
        coincide (identity link), so no conversion is applied; the z
        intercept is mapped from the logit scale back to a probability
        with the inverse link before comparison. Biases are thus in
        physical units (seconds for t, threshold units for a, probability
        for z).
        """
        records = []
        for (param, gt_lp) in group_truth.items():
            if param not in summary_df.index:
                continue
            rec_row = summary_df.loc[param]
            rec_mean = float(rec_row['mean'])
            hdi_low = float(rec_row['hdi_3%'])
            hdi_high = float(rec_row['hdi_97%'])
            family = param.split('_')[0] if '_' in param else 'other'
            is_intercept = 'Intercept' in param
            gt_compare = self._apply_link_and_clip(family, gt_lp) if is_intercept and family == 'z' else gt_lp
            bias = rec_mean - gt_compare
            is_covered = hdi_low <= gt_compare <= hdi_high
            param_type = 'Intercept' if is_intercept else 'ConditionEffect'
            records.append({'pipeline_hash': self.active_hash, 'mode': mode, 'iteration': iteration, 'Parameter': param, 'Family': family, 'Type': param_type, 'Ground_Truth': gt_compare, 'Recovered_Mean': rec_mean, 'Bias': bias, 'Abs_Bias': np.abs(bias), 'Sq_Error': bias ** 2, 'HDI_3': hdi_low, 'HDI_97': hdi_high, 'HDI_Width': hdi_high - hdi_low, 'Coverage': int(is_covered), 'Refit_Converged': converged, 'Refit_Max_Rhat': max_rhat, 'Refit_F_ESS_Bulk': metrics.get('f_bulk', np.nan), 'Refit_F_ESS_Tail': metrics.get('f_tail', np.nan), 'Refit_N_Rhat': metrics.get('n_rhat', np.nan)})
        return records

    def compute_subject_intercept_recovery(self, subject_truths: Dict[str, Dict[str, Dict[str, float]]], summary_df: pd.DataFrame, iteration: int, mode: str, converged: bool) -> List[Dict]:
        """
        Evaluates recovery of the subject-level random intercepts that the
        hierarchical model estimates under group_only_regressors=True.

        Ground truth for subject s and family p is the physical-scale
        baseline-condition value subject_truths[s][baseline][p]; given the
        shared-deviation generation this is that subject's random intercept.
        The recovered counterpart is the posterior mean of the subject node
        ('{p}_Intercept_subj.{s}' for regression families, '{p}_subj.{s}'
        otherwise).

        Comparison is on the physical scale: exact for v/a/t (identity
        link); for z the posterior-summary convention used for the
        group-level z intercept is reused (no additional transform). The
        primary diagnostic is the across-subject correlation, computed in
        export_subject_recovery_summary, rather than interval coverage.
        """
        records = []
        baseline = CFG.baseline_condition
        for (subj, by_emo) in subject_truths.items():
            if baseline not in by_emo:
                continue
            for p in ['v', 'a', 't', 'z']:
                true_phys = by_emo[baseline].get(p)
                if true_phys is None:
                    continue
                candidates = [f'{p}_Intercept_subj.{subj}', f'{p}_subj.{subj}']
                node = next((c for c in candidates if c in summary_df.index), None)
                if node is None:
                    continue
                records.append({'pipeline_hash': self.active_hash, 'mode': mode, 'iteration': iteration, 'subj_idx': subj, 'Family': p, 'True_Subject_Intercept': float(true_phys), 'Recovered_Subject_Mean': float(summary_df.loc[node, 'mean']), 'Refit_Converged': converged})
        return records

    def export_aggregate_summary(self, mode: str):
        """
        Computes and exports aggregate recovery metrics across
        all converged iterations.
        """
        csv_path = PATHS['recovery'] / f'recovery_all_iterations_{self.target_model}_{mode}.csv'
        if not csv_path.exists():
            return
        df = pd.read_csv(csv_path)
        if 'Refit_Converged' in df.columns:
            df = df[df['Refit_Converged'] == True]
        if df.empty:
            return
        agg = df.groupby(['Family', 'Type']).agg(N_Iterations=('iteration', 'nunique'), N_Params=('Parameter', 'nunique'), RMSE=('Sq_Error', lambda x: np.sqrt(x.mean())), Mean_Abs_Bias=('Abs_Bias', 'mean'), Mean_HDI_Width=('HDI_Width', 'mean'), Coverage_Rate=('Coverage', 'mean')).reset_index()
        agg_path = PATHS['tables_supp'] / f'recovery_aggregate_summary_{self.target_model}_{mode}.csv'
        agg.to_csv(agg_path, index=False)
        if len(df) >= 3:
            (r_val, p_val) = stats.pearsonr(df['Ground_Truth'], df['Recovered_Mean'])
            rmse_global = float(np.sqrt(df['Sq_Error'].mean()))
            self.logger.info(f'  [{mode}] Global: r={r_val:.3f} (p={p_val:.2e}), RMSE={rmse_global:.4f}')
        self.logger.info(f'\n{agg.to_string(index=False)}')

    def export_subject_recovery_summary(self, mode: str):
        """
        Aggregates subject-level intercept recovery across all converged
        iterations: per-family across-subject Pearson correlation, OLS
        slope, and RMSE between the true and recovered subject intercepts
        (pooled over subjects and iterations). Emits a summary table and an
        identity scatter (true vs recovered) per parameter family.

        The across-subject correlation indexes whether between-subject
        differences in the baseline parameters are recovered — the
        complement to the group-level focal-parameter diagnostics.
        """
        subj_csv = PATHS['recovery'] / f'recovery_subject_pairs_{self.target_model}_{mode}.csv'
        if not subj_csv.exists():
            self.logger.warning(f'  [{mode}] No subject-level recovery data. Subject summary skipped.')
            return
        df = pd.read_csv(subj_csv)
        if 'Refit_Converged' in df.columns:
            df = df[df['Refit_Converged'] == True]
        if df.empty:
            self.logger.warning(f'  [{mode}] No converged subject-level data.')
            return
        rows = []
        for (fam, g) in df.groupby('Family'):
            t = g['True_Subject_Intercept'].values
            r = g['Recovered_Subject_Mean'].values
            if len(t) < 3:
                continue
            rows.append({'Family': fam, 'N_Pairs': int(len(g)), 'N_Subjects': int(g['subj_idx'].nunique()), 'N_Iterations': int(g['iteration'].nunique()), 'Pearson_r': float(np.corrcoef(t, r)[0, 1]), 'OLS_Slope': float(np.polyfit(t, r, 1)[0]), 'RMSE': float(np.sqrt(np.mean((r - t) ** 2)))})
        out = pd.DataFrame(rows)
        out_path = PATHS['tables_supp'] / f'recovery_subject_intercepts_{self.target_model}_{mode}.csv'
        out.to_csv(out_path, index=False)
        self.logger.info(f'  [{mode}] Subject-level intercept recovery:\n{out.to_string(index=False)}')
