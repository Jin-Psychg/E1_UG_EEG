# -*- coding: utf-8 -*-
"""
=============================================================================
STEP 6: Multi-Iteration Dual-Track Parameter Recovery Validation
=============================================================================
Pipeline Position:
  Upstream:   Step 4 (reads final_model_selection_audit.csv to identify
              winning model; reads .nc file from models/)
              Step 1 (reads hddm_data_unfair.csv for design skeleton)
  Downstream: None (terminal validation step)

Methodological Purpose:
  - Validates the structural identifiability of the specified model
    via two complementary forward-simulation-and-refitting paradigms:
    1. Posterior-Anchored: Extracts pseudo-truth from the empirical
       joint posterior to evaluate self-consistency.
    2. Prior-Predictive: Samples pseudo-truth from ecologically valid
       informative priors to stress-test identifiability.
  - Executes N_ITERATIONS (default 20) independent recovery cycles
    per mode to obtain distributional estimates of Bias, RMSE,
    Coverage Rate, and Correlation (Wilson & Collins, 2019, eLife).
  - Constructs synthetic datasets preserving the empirical trial
    skeleton WITH subject-level parameter variability drawn from
    the hierarchical prior structure (Lerche & Voss, 2016).
  - Validates refit convergence before computing recovery metrics.
  - Implements memory guard, incremental result persistence, and
    checkpoint resume to survive interruptions.

=============================================================================
"""

import os
import gc
import time
import logging
import traceback
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
import arviz as az
import hddm
from hddm.generate import gen_rand_data

from scipy.special import expit, logit
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import seaborn as sns

# -----------------------------------------------------------------------------
# CONFIGURATION IMPORT
# -----------------------------------------------------------------------------
try:
    from hddm_config import (
        CFG,
        load_active_lineage_state,
        identify_winning_model,
        check_memory_headroom
    )
except ImportError:
    raise ImportError(
        "CRITICAL ERROR: 'hddm_config.py' unresolved. "
        "Execution of Step 2a is mandatory."
    )

PATHS = CFG.initialize_directories()

# Deterministic seed from configuration
np.random.seed(CFG.base_seed)

# Publication-grade aesthetics
sns.set_theme(style="ticks", palette="colorblind")
OKABE_ITO = [
    '#E69F00', '#56B4E9', '#009E73', '#F0E442',
    '#0072B2', '#D55E00', '#CC79A7', '#000000'
]
plt.rcParams.update({
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.prop_cycle': plt.cycler(color=OKABE_ITO),
    'font.size': 11,
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
    'legend.frameon': False,
    'figure.autolayout': True
})

# =============================================================================
# RECOVERY CONFIGURATION CONSTANTS
# =============================================================================
# 20 iterations per mode provides sufficient distributional stability
# for Bias, RMSE, and Coverage while keeping total runtime feasible
# for HDDMRegressor recovery refits (2-5 hours each).
N_ITERATIONS_FINAL = 20
N_ITERATIONS_DEBUG = 3

# Consecutive genuine exceptions (MemoryError, numerical failures)
# before terminating a recovery mode.
MAX_CONSECUTIVE_FAILURES = 5

# Convergence threshold for recovery refits. Relaxed relative to
# Step 2b main fitting (1.01 focal / 1.05 nuisance) because
# recovery refits use lighter MCMC budgets.
RECOVERY_RHAT_THRESHOLD = 1.10

# Adaptive sampling constants for recovery refits.
# Recovery-specific: lighter ceilings than Step 2b main fitting
# to bound total compute per iteration.
RECOVERY_MAX_ADAPTIVE_CYCLES = 3
RECOVERY_MAX_RHAT_EXTENSIONS = 2
RECOVERY_RHAT_IMPROVEMENT_MIN = 0.005

# Recovery-specific ESS thresholds. Relaxed relative to Step 2b
# (1000 bulk / 500 tail) because recovery only needs sufficient
# precision for bias/coverage estimation, not full posterior
# characterization.
RECOVERY_ESS_BULK_FOCAL = 400.0
RECOVERY_ESS_TAIL_FOCAL = 200.0


# =============================================================================
# LOGGING SETUP
# =============================================================================
def _setup_recovery_logger() -> logging.Logger:
    """Initializes dual-sink logging for recovery module."""
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    logger = logging.getLogger(f'hddm_recovery_{ts}')
    logger.handlers = []
    logger.setLevel(logging.INFO)

    fmt = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )
    fh = logging.FileHandler(
        PATHS['audit'] / f'dual_recovery_{ts}.log',
        encoding='utf-8'
    )
    ch = logging.StreamHandler()
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger


# =============================================================================
# INPUT DATA VALIDATION (ported from Step 2b)
# =============================================================================
def validate_empirical_data(
    data_path: str, logger: logging.Logger
) -> pd.DataFrame:
    """
    Enforces HDDM structural requirements and datatype constraints
    on the empirical design matrix used as recovery skeleton.

    Validates:
      - Mandatory columns: subj_idx, rt, response
      - RT values are numeric and positive
      - Response values are binary {0, 1}
      - Baseline emotion condition exists in the data
      - No NaN values in critical columns
    """
    if not os.path.exists(data_path):
        raise FileNotFoundError(
            f"Input data path unresolved: {data_path}"
        )

    df = pd.read_csv(data_path)
    logger.info(
        f"Empirical data loaded: {df.shape[0]} trials, "
        f"{df.shape[1]} columns"
    )

    # HDDM structural dependency validation
    required_cols = {'subj_idx', 'rt', 'response'}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(
            f"Mandatory HDDM columns missing: {missing}"
        )

    # Datatype normalization
    df['subj_idx'] = df['subj_idx'].astype(str)
    df['rt'] = pd.to_numeric(df['rt'], errors='coerce')
    df['response'] = pd.to_numeric(df['response'], errors='coerce')

    # Data integrity enforcement: exclude NaN entries
    n_before = len(df)
    df = df.dropna(subset=['rt', 'response'])
    n_dropped = n_before - len(df)
    if n_dropped > 0:
        logger.warning(
            f"Data exclusion: {n_dropped} rows dropped "
            f"due to NaN rt/response."
        )

    # Baseline condition verification
    if 'emotion' in df.columns:
        if CFG.baseline_condition not in df['emotion'].unique():
            raise ValueError(
                f"Baseline condition '{CFG.baseline_condition}' "
                f"absent. Available levels: "
                f"{df['emotion'].unique().tolist()}"
            )

    n_subjects = df['subj_idx'].nunique()
    n_conditions = (
        df['emotion'].nunique() if 'emotion' in df.columns else 0
    )
    logger.info(
        f"Validation complete: {n_subjects} subjects, "
        f"{n_conditions} conditions, {len(df)} trials retained."
    )
    logger.info(
        f"RT bounds: [{df['rt'].min():.3f}, "
        f"{df['rt'].max():.3f}] seconds."
    )

    return df


# =============================================================================
# STRATIFIED CONVERGENCE DIAGNOSTICS (adapted from Step 2b)
# =============================================================================
def _evaluate_recovery_convergence(
    infdata: az.InferenceData, logger: logging.Logger
) -> Tuple[bool, Dict[str, float], pd.DataFrame]:
    """
    Computes Gelman-Rubin (R-hat) and Effective Sample Size (ESS)
    statistics with stratified thresholds for recovery refits.

    Focal parameters (group-level intercepts and treatment contrasts)
    require both R-hat and ESS evaluation. Nuisance parameters
    (subject-level deviations, variance terms) require R-hat only,
    following Vehtari et al. (2021) recommendations for hierarchical
    models with link-function-induced autocorrelation.

    Returns:
      converged:  Boolean indicating all criteria satisfied.
      metrics:    Dictionary of computed diagnostic extrema.
      summary_df: Full ArviZ statistical summary DataFrame.
    """
    summary_df = az.summary(infdata, round_to=4, hdi_prob=0.94)

    # Parameter stratification using CFG's canonical classifier
    focal_params = CFG.identify_focal_parameters(
        summary_df.index.tolist()
    )
    summary_df['param_class'] = [
        'focal' if p in focal_params else 'nuisance'
        for p in summary_df.index
    ]

    focal_df = summary_df[summary_df["param_class"] == "focal"]
    nuisance_df = summary_df[
        summary_df["param_class"] == "nuisance"
    ]

    # Extremum metric extraction
    metrics = {
        "f_rhat": (
            focal_df["r_hat"].max()
            if not focal_df.empty else 1.0
        ),
        "f_bulk": (
            focal_df["ess_bulk"].min()
            if not focal_df.empty else float("inf")
        ),
        "f_tail": (
            focal_df["ess_tail"].min()
            if ("ess_tail" in focal_df.columns
                and not focal_df.empty)
            else float("inf")
        ),
        "n_rhat": (
            nuisance_df["r_hat"].max()
            if not nuisance_df.empty else 1.0
        ),
        "n_bulk": (
            nuisance_df["ess_bulk"].min()
            if not nuisance_df.empty else float("inf")
        ),
        "n_tail": (
            nuisance_df["ess_tail"].min()
            if ("ess_tail" in nuisance_df.columns
                and not nuisance_df.empty)
            else float("inf")
        ),
    }

    # Criteria evaluation with recovery-specific thresholds
    focal_ok = (
        (metrics["f_rhat"] <= RECOVERY_RHAT_THRESHOLD)
        and (metrics["f_bulk"] >= RECOVERY_ESS_BULK_FOCAL)
        and (metrics["f_tail"] >= RECOVERY_ESS_TAIL_FOCAL)
    )

    # Nuisance convergence: R-hat only.
    nuisance_ok = (
        metrics["n_rhat"] <= RECOVERY_RHAT_THRESHOLD
    )

    converged = focal_ok and nuisance_ok

    logger.info(
        f"    FOCAL   | R-hat={metrics['f_rhat']:.3f} "
        f"(<={RECOVERY_RHAT_THRESHOLD}) | "
        f"ESS_bulk={metrics['f_bulk']:.0f} "
        f"(>={RECOVERY_ESS_BULK_FOCAL:.0f}) | "
        f"ESS_tail={metrics['f_tail']:.0f} "
        f"(>={RECOVERY_ESS_TAIL_FOCAL:.0f}) | "
        f"{'PASS' if focal_ok else 'FAIL'}"
    )
    logger.info(
        f"    NUISANCE| R-hat={metrics['n_rhat']:.3f} "
        f"(<={RECOVERY_RHAT_THRESHOLD}) | "
        f"ESS_bulk={metrics['n_bulk']:.0f} | "
        f"ESS_tail={metrics['n_tail']:.0f} | "
        f"{'PASS' if nuisance_ok else 'FAIL'}"
    )

    return converged, metrics, summary_df


# =============================================================================
# DYNAMIC REGRESSOR FACTORY
# =============================================================================
def _build_regressors(
    model_name: str, baseline: str
) -> List[str]:
    """
    Constructs Patsy formulas matching Step 2b specifications.
    ALL 4 DDM parameters get explicit formulas (treatment-coded
    or intercept-only) to ensure dockerHDDM compatibility.
    """
    name_lower = model_name.lower()
    regressors = []

    for param in ['v', 'a', 't', 'z']:
        if name_lower != 'null' and param in name_lower:
            regressors.append(
                f"{param} ~ C(emotion, "
                f"Treatment('{baseline}'))"
            )
        else:
            regressors.append(f"{param} ~ 1")

    return regressors


# =============================================================================
# FORWARD LINK FUNCTIONS — PHYSICAL → LP CONVERSION
# =============================================================================
def _physical_to_lp(
    param_family: str, value: float, is_intercept: bool
) -> float:
    """
    Maps a posterior-summary parameter value onto the scale that
    HDDMRegressor uses for forward simulation.

    Called with formula strings and the default link, HDDMRegressor uses
    the identity link for v, a and t, and the logit link for z. Intercepts
    are therefore returned unchanged for v/a/t and mapped with the logit
    for z. Treatment contrasts are additive deviations on the same scale
    and are returned unchanged for all families.

    Parameters:
      param_family:  One of 'v', 'a', 't', 'z'.
      value:         The raw value from az.summary() or a posterior draw.
      is_intercept:  True for Intercept parameters, False for Treatment
                     contrast coefficients.
    """
    # Treatment contrasts are already in LP scale — pass through
    if not is_intercept:
        return float(value)

    # Intercepts require physical → LP conversion
    if param_family == 'v':
        return float(value)
    elif param_family == 'a':
        # identity link: boundary separation is on the physical scale
        return float(value)
    elif param_family == 't':
        # identity link: non-decision time is on the physical scale
        return float(value)
    elif param_family == 'z':
        return float(logit(np.clip(value, 1e-6, 1.0 - 1e-6)))
    return float(value)


# =============================================================================
# CORE CLASS: SINGLE-MODEL PARAMETER RECOVERY ENGINE
# =============================================================================
class ParameterRecoveryEngine:
    """
    Orchestrates N-iteration Posterior-Anchored and Prior-Predictive
    identifiability evaluations for a single specified HDDM model.

    Simplified interface: accepts a single target_model
    string directly, without multi-model orchestration overhead.
    """

    def __init__(
        self,
        target_model: str,
        empirical_data_path: str = 'hddm_data_unfair.csv',
        n_iterations: Optional[int] = None
    ):
        self.logger = _setup_recovery_logger()

        self.active_lineage = load_active_lineage_state(
            PATHS, self.logger
        )
        self.active_hash = (
            self.active_lineage['pipeline_hash']
        )

        # Validate target model against canonical architecture list
        valid_models = [
            m.lower() for m in CFG.final_all_models
        ]
        target_lower = target_model.strip().lower()
        if target_lower not in valid_models:
            raise ValueError(
                f"Target model '{target_model}' is not a valid "
                f"architecture. Valid options: {valid_models}"
            )
        self.target_model = target_lower

        # Log the Step 4 audit winner for provenance record
        audit_winner = identify_winning_model(PATHS)
        self.logger.info(
            f"Step 4 audit winner: [{audit_winner.upper()}]"
        )
        self.logger.info(
            f"Recovery target (user-specified): "
            f"[{self.target_model.upper()}]"
        )

        self.empirical_data_path = empirical_data_path

        # Recovery MCMC hyperparameters (lighter than main fitting)
        if CFG.run_mode == 'debug':
            self.recovery_chains = 2
            self.recovery_samples = 500
            self.recovery_burn = 100
            self.n_iterations = N_ITERATIONS_DEBUG
        else:
            self.recovery_chains = CFG.n_chains
            self.recovery_samples = 3000
            self.recovery_burn = 1000
            self.n_iterations = N_ITERATIONS_FINAL

        # User override for iteration count (enables easy extension
        # without modifying global constants). Checkpoint resume
        # automatically skips already-completed iterations.
        if n_iterations is not None:
            self.n_iterations = n_iterations

        # Validate empirical data before use as skeleton
        self.empirical_df = validate_empirical_data(
            empirical_data_path, self.logger
        )
        self.n_subjects = self.empirical_df['subj_idx'].nunique()

        self.logger.info("=" * 70)
        self.logger.info(
            f"PARAMETER RECOVERY INITIATED "
            f"(Mode: {CFG.run_mode.upper()})"
        )
        self.logger.info(
            f"Pipeline Hash: {self.active_hash[:24]}..."
        )
        self.logger.info(
            f"Target Model: [{self.target_model.upper()}]"
        )
        self.logger.info(
            f"Iterations: {self.n_iterations} per mode"
        )
        self.logger.info(
            f"Recovery MCMC: {self.recovery_samples} samples, "
            f"{self.recovery_burn} burn, "
            f"{self.recovery_chains} chains"
        )
        self.logger.info(
            f"Design: {self.n_subjects} subjects"
        )
        self.logger.info(
            f"Adaptive: max {RECOVERY_MAX_ADAPTIVE_CYCLES} "
            f"cycles, ESS_bulk>={RECOVERY_ESS_BULK_FOCAL:.0f}, "
            f"ESS_tail>={RECOVERY_ESS_TAIL_FOCAL:.0f}"
        )
        self.logger.info("=" * 70)

    # -----------------------------------------------------------------
    # INVERSE LINK FUNCTIONS (LP → PHYSICAL)
    # -----------------------------------------------------------------
    @staticmethod
    def _apply_link_and_clip(
        param_family: str, lp_val: float
    ) -> float:
        """
        Applies the HDDMRegressor inverse links and enforces bounds.
        Identity for v, a and t; logit for z.
        v: identity, clipped to [-8, 8]
        a: identity, clipped to [0.2, 4.0]
        t: identity, clipped to [0.05, 2.0]
        z: expit, clipped to [0.05, 0.95]
        """
        if param_family == 'v':
            return float(np.clip(lp_val, -8.0, 8.0))
        elif param_family == 'a':
            return float(np.clip(lp_val, 0.2, 4.0))
        elif param_family == 't':
            return float(np.clip(lp_val, 0.05, 2.0))
        elif param_family == 'z':
            return float(np.clip(expit(lp_val), 0.05, 0.95))
        return lp_val

    # -----------------------------------------------------------------
    # GROUND TRUTH ESTABLISHMENT
    # With scale-aligned physical → LP conversion
    # -----------------------------------------------------------------
    def establish_ground_truth(
        self, mode: str, iteration: int
    ) -> Tuple[Dict[str, float], Dict[str, Dict[str, float]]]:
        """
        Synthesizes pseudo-truth parameter matrices.

        Returns:
          group_truth: Dict of group-level LP-scale parameters.
          subject_truths: Dict mapping subj_idx -> dict of
                         physical-scale parameters per condition.
                         Includes subject-level variability drawn
                         from hierarchical prior structure.

        Posterior mode: az.summary() of the fitted .nc returns parameter
        means on the scale HDDMRegressor uses (identity for v/a/t, logit
        for z). Intercepts are mapped to that scale with _physical_to_lp;
        treatment contrasts are additive deviations and are kept unchanged.
        The same mapping is applied when sampling an individual posterior
        draw (iteration > 0).
        """
        # Unique seed per mode x iteration
        iter_seed = (
            CFG.base_seed + iteration * 100
            + (0 if mode == 'posterior' else 50)
        )
        np.random.seed(iter_seed)

        group_truth = {}
        model_lower = self.target_model.lower()

        if mode == 'posterior':
            nc_path = (
                PATHS['models']
                / f"hddm_{self.target_model}.nc"
            )
            if not nc_path.exists():
                raise FileNotFoundError(
                    f"InferenceData unresolved: {nc_path.name}"
                )

            infdata = az.from_netcdf(str(nc_path))
            summary = az.summary(infdata, round_to=4)

            # Extract focal fixed-effect parameters
            focal_indices = [
                idx for idx in summary.index
                if ('Intercept' in idx or 'Treatment' in idx
                    or 'C(emotion' in idx)
                and not any(
                    s in idx for s in
                    ['_subj', '_std', '_var', '_log', '_trans']
                )
            ]

            # =========================================================
            # Map posterior-summary values onto the generative scale.
            # HDDMRegressor uses the identity link for v/a/t and the logit
            # link for z:
            #   Intercepts: v/a/t unchanged (physical = linear predictor);
            #               z mapped with the logit.
            #   Contrasts:  additive deviations on the same scale; unchanged.
            # =========================================================
            if iteration == 0:
                # Iteration 0: use posterior mean
                for param_name in focal_indices:
                    raw_val = float(summary.loc[param_name, 'mean'])
                    family = param_name.split('_')[0]
                    is_intercept = 'Intercept' in param_name
                    group_truth[param_name] = _physical_to_lp(
                        family, raw_val, is_intercept
                    )
            else:
                # Iteration > 0: sample a single posterior draw
                # Same Intercept/Contrast distinction applies
                post = infdata.posterior
                draw_idx = np.random.randint(
                    0, post.dims['draw']
                )
                chain_idx = np.random.randint(
                    0, post.dims['chain']
                )

                for param_name in focal_indices:
                    if param_name in post.data_vars:
                        raw_val = float(
                            post[param_name]
                            .values[chain_idx, draw_idx]
                        )
                    else:
                        # Fallback to summary mean if variable
                        # not found in posterior group
                        raw_val = float(
                            summary.loc[param_name, 'mean']
                        )

                    family = param_name.split('_')[0]
                    is_intercept = 'Intercept' in param_name
                    group_truth[param_name] = _physical_to_lp(
                        family, raw_val, is_intercept
                    )

            # Log ground truth for audit trail
            self.logger.info(
                f"    Ground truth ({mode}, iter {iteration}):"
            )
            for k, v in group_truth.items():
                family = k.split('_')[0]
                phys_check = self._apply_link_and_clip(family, v)
                self.logger.info(
                    f"      {k}: LP={v:.4f} → phys={phys_check:.4f}"
                )

            del infdata
            gc.collect()

        elif mode == 'prior':
            # Prior-predictive mode: sample from ecologically
            # valid informative priors. These are generated
            # directly in LP scale — no conversion needed.
            for param_family in ['v', 'a', 't', 'z']:
                is_varying = (
                    param_family in model_lower
                    and model_lower != 'null'
                )

                # Intercept synthesis (in LP scale)
                if param_family == 'v':
                    # v uses identity link: LP = physical
                    phys_val = stats.norm.rvs(
                        loc=1.0, scale=1.5
                    )
                    lp_int = phys_val
                elif param_family == 'a':
                    # identity link: parameter on the physical scale
                    phys_val = stats.gamma.rvs(
                        a=9.0, scale=0.166
                    )
                    phys_val = np.clip(phys_val, 0.5, 3.5)
                    lp_int = phys_val
                elif param_family == 't':
                    # identity link: parameter on the physical scale
                    phys_val = stats.truncnorm.rvs(
                        a=(0.1 - 0.3) / 0.1,
                        b=(0.5 - 0.3) / 0.1,
                        loc=0.3, scale=0.1
                    )
                    phys_val = np.clip(phys_val, 0.05, 0.8)
                    lp_int = phys_val
                elif param_family == 'z':
                    # z uses logit link: LP = logit(physical)
                    phys_val = stats.beta.rvs(a=5, b=5)
                    phys_val = np.clip(phys_val, 0.1, 0.9)
                    lp_int = logit(phys_val)
                else:
                    lp_int = 0.0

                group_truth[
                    f"{param_family}_Intercept"
                ] = float(lp_int)

                # Treatment contrasts (always in LP scale;
                # contrasts are additive deviations on LP scale)
                if is_varying:
                    for emo in CFG.emotion_order:
                        if emo == CFG.baseline_condition:
                            continue

                        effect_key = (
                            f"{param_family}_C(emotion, "
                            f"Treatment('"
                            f"{CFG.baseline_condition}'))"
                            f"[T.{emo}]"
                        )

                        if param_family == 'v':
                            eff = stats.norm.rvs(
                                loc=0, scale=0.5
                            )
                        elif param_family in ['a', 'z']:
                            eff = stats.norm.rvs(
                                loc=0, scale=0.1
                            )
                        elif param_family == 't':
                            eff = stats.norm.rvs(
                                loc=0, scale=0.05
                            )
                        else:
                            eff = 0.0

                        group_truth[effect_key] = float(eff)

        # Generate subject-level parameters with hierarchical
        # variability. Subject-level SD (LP scale) per family.
        subject_truths = {}
        subjects = self.empirical_df['subj_idx'].unique()
        # Subject-level SD for the hierarchical deviations, on each
        # parameter's generative scale (drift for v; physical for a, t;
        # logit for z). In posterior mode these are taken from the fitted
        # group-level SDs (_Intercept_std) so synthetic data reproduce the
        # empirical between-subject spread; in prior mode ecologically
        # plausible values matched to the fitted scale are used.
        subj_sd_default = {'v': 1.4, 'a': 0.45, 't': 0.19, 'z': 0.25}
        if mode == 'posterior':
            subj_sd = {}
            for _p in ['v', 'a', 't', 'z']:
                _k = f"{_p}_Intercept_std"
                subj_sd[_p] = (float(summary.loc[_k, 'mean'])
                               if _k in summary.index
                               else subj_sd_default[_p])
        else:
            subj_sd = dict(subj_sd_default)

        for subj in subjects:
            # Draw ONE subject-level deviation per parameter, shared across
            # all emotion conditions, realising a per-subject random
            # intercept (the hierarchical structure assumed by
            # group_only_regressors=True). subject_truths[subj][baseline]
            # therefore defines a well-posed per-subject intercept truth
            # for the subject-level recovery diagnostic.
            subj_dev = {
                p: np.random.normal(0, subj_sd[p])
                for p in ['v', 'a', 't', 'z']
            }
            subj_params = {}
            for emo in CFG.emotion_order:
                cell_params = {}
                for p in ['v', 'a', 't', 'z']:
                    # Group-level LP for this condition
                    lp_val = group_truth.get(
                        f"{p}_Intercept", 0.0
                    )
                    if emo != CFG.baseline_condition:
                        effect_key = (
                            f"{p}_C(emotion, "
                            f"Treatment('"
                            f"{CFG.baseline_condition}'))"
                            f"[T.{emo}]"
                        )
                        if effect_key not in group_truth:
                            effect_key = (
                                f"{p}_C(emotion)[T.{emo}]"
                            )
                        lp_val += group_truth.get(
                            effect_key, 0.0
                        )

                    # Add the subject's shared random-intercept deviation
                    # (LP scale), constant across emotion conditions
                    subj_lp = lp_val + subj_dev[p]

                    # Inverse link: LP → physical (with clipping)
                    cell_params[p] = self._apply_link_and_clip(
                        p, subj_lp
                    )

                subj_params[emo] = cell_params
            subject_truths[subj] = subj_params

        return group_truth, subject_truths

    # -----------------------------------------------------------------
    # SYNTHETIC DATA GENERATION
    # -----------------------------------------------------------------
    def generate_synthetic_data(
        self,
        subject_truths: Dict[str, Dict[str, Dict[str, float]]],
        iteration: int,
        mode: str
    ) -> pd.DataFrame:
        """
        Constructs synthetic data using HDDM's internal forward
        simulation. Each subject x condition cell uses that
        subject's unique parameters (with hierarchical variability).
        """
        trial_rows = []

        for (subj, emo), group in self.empirical_df.groupby(
            ['subj_idx', 'emotion']
        ):
            n_trials = len(group)
            phys_params = subject_truths[subj][emo]

            # Forward simulation via hddm.generate
            sim_res = gen_rand_data(phys_params, size=n_trials)
            sim_df = (
                sim_res[0]
                if isinstance(sim_res, tuple)
                else sim_res
            )

            row_data = pd.DataFrame({
                'subj_idx': subj,
                'emotion': emo,
                'rt': sim_df['rt'].values,
                'response': sim_df['response'].values
            })

            # Tag true parameters for this cell
            for p in ['v', 'a', 't', 'z']:
                row_data[f'{p}_true'] = phys_params[p]

            trial_rows.append(row_data)

        return pd.concat(trial_rows, ignore_index=True)

    # -----------------------------------------------------------------
    # RECOVERY REFIT WITH EXPLICIT ARTIFACT PERSISTENCE
    # -----------------------------------------------------------------
    def execute_recovery_refit(
        self,
        synth_df: pd.DataFrame,
        iteration: int,
        mode: str
    ) -> Tuple[Optional[pd.DataFrame], bool, float,
               Dict[str, float]]:
        """
        Executes structural refitting of synthetic data with
        stratified convergence diagnostics and adaptive sampling.

        Phase 4 artifact persistence: after all adaptive
        cycles complete, explicitly saves accumulated InferenceData
        to .nc via model.to_infdata().to_netcdf(). This mirrors
        Step 2b's Phase 4 pattern and ensures disk artifacts
        reflect the FULL accumulated posterior, not just the last
        adaptive extension.

        Returns:
          summary_df: ArviZ summary (or None on failure).
          converged:  Whether all stratified criteria are satisfied.
          max_rhat:   Maximum R-hat among focal parameters.
          metrics:    Full diagnostic metrics dictionary.
        """
        synth_df = synth_df.copy()
        synth_df['subj_idx'] = synth_df['subj_idx'].astype(str)

        regressors = _build_regressors(
            self.target_model, CFG.baseline_condition
        )

        # Match Step 2b: all 4 parameters always included
        full_include = ['v', 'a', 't', 'z']

        model = hddm.HDDMRegressor(
            synth_df,
            regressors,
            include=full_include,
            is_group_model=True,
            group_only_regressors=CFG.group_only_regressors,
            keep_regressor_trace=CFG.keep_regressor_trace,
            informative=CFG.use_informative_priors,
            p_outlier=CFG.p_outlier
        )

        # Unique save path per iteration to avoid file conflicts
        save_prefix = str(
            PATHS['recovery']
            / f"recovery_{self.target_model}_{mode}_iter{iteration}"
        )

        # Phase 1: Initial sampling (runs to completion)
        infdata = model.sample(
            self.recovery_samples,
            burn=self.recovery_burn,
            thin=CFG.default_thin,
            chains=self.recovery_chains,
            return_infdata=True,
            loglike=False,
            ppc=False,
            save_name=save_prefix
        )

        # Phase 2: Stratified convergence evaluation
        converged, metrics, summary_df = (
            _evaluate_recovery_convergence(infdata, self.logger)
        )

        # Phase 3: Adaptive sampling loop
        total_samples = self.recovery_samples
        max_samples = self.recovery_samples * 2
        cycle = 0
        prev_metrics = None
        rhat_extension_count = 0

        while (not converged
               and cycle < RECOVERY_MAX_ADAPTIVE_CYCLES):
            cycle += 1

            # Compute extension size from focal ESS deficits
            deficit_ratios = []

            if metrics["f_bulk"] < RECOVERY_ESS_BULK_FOCAL:
                deficit_ratios.append(
                    RECOVERY_ESS_BULK_FOCAL
                    / max(metrics["f_bulk"], 1.0)
                )
            if metrics["f_tail"] < RECOVERY_ESS_TAIL_FOCAL:
                deficit_ratios.append(
                    RECOVERY_ESS_TAIL_FOCAL
                    / max(metrics["f_tail"], 1.0)
                )

            if deficit_ratios:
                # ESS-driven: scale by worst focal ESS deficit
                deficit_ratio = max(deficit_ratios)
                added_samples = max(
                    500,
                    int(total_samples
                        * (deficit_ratio - 1) * 1.25)
                )
            else:
                # R-hat-driven: moderate fixed extension
                deficit_ratio = 1.3
                added_samples = max(
                    500,
                    int(self.recovery_samples * 0.30)
                )
                rhat_extension_count += 1

            # R-hat plateau detection
            if (prev_metrics is not None
                    and rhat_extension_count > 0):
                prev_worst_rhat = max(
                    prev_metrics["f_rhat"],
                    prev_metrics["n_rhat"]
                )
                curr_worst_rhat = max(
                    metrics["f_rhat"],
                    metrics["n_rhat"]
                )
                rhat_improvement = (
                    prev_worst_rhat - curr_worst_rhat
                )

                self.logger.info(
                    f"    R-hat change: "
                    f"{prev_worst_rhat:.4f} -> "
                    f"{curr_worst_rhat:.4f} "
                    f"(improvement="
                    f"{rhat_improvement:+.4f})"
                )

                if rhat_improvement < RECOVERY_RHAT_IMPROVEMENT_MIN:
                    self.logger.warning(
                        f"    R-hat improvement insufficient "
                        f"(<{RECOVERY_RHAT_IMPROVEMENT_MIN}) "
                        f"after R-hat extension round "
                        f"{rhat_extension_count}. "
                        f"Terminating adaptive extension."
                    )
                    break

            if rhat_extension_count >= RECOVERY_MAX_RHAT_EXTENSIONS:
                self.logger.info(
                    f"    R-hat extension limit reached "
                    f"({RECOVERY_MAX_RHAT_EXTENSIONS} rounds). "
                    f"Terminating adaptive extension."
                )
                break

            prev_metrics = metrics.copy()

            # Sample ceiling enforcement
            if total_samples + added_samples > max_samples:
                added_samples = max_samples - total_samples
                if added_samples <= 0:
                    self.logger.warning(
                        f"    Sample ceiling "
                        f"({max_samples}) reached. "
                        f"Terminating adaptive cycles."
                    )
                    break

            self.logger.info(
                f"    [Adaptive Cycle "
                f"{cycle}/{RECOVERY_MAX_ADAPTIVE_CYCLES}] "
                f"Appending {added_samples} samples "
                f"(Deficit Ratio: {deficit_ratio:.2f})..."
            )

            model.sample(
                added_samples,
                burn=0,
                thin=CFG.default_thin,
                chains=self.recovery_chains,
                return_infdata=True,
                loglike=False,
                ppc=False,
                save_name=save_prefix
            )

            total_samples += added_samples

            # Regenerate InferenceData from accumulated trace
            try:
                infdata = model.to_infdata(
                    loglike=False, ppc=False
                )
            except Exception as e:
                self.logger.warning(
                    f"    model.to_infdata() failed: {e}. "
                    f"Diagnostics may reflect stale trace."
                )

            # Re-evaluate convergence
            converged, metrics, summary_df = (
                _evaluate_recovery_convergence(
                    infdata, self.logger
                )
            )

        # Log final adaptive outcome
        if cycle > 0:
            self.logger.info(
                f"    Adaptive sampling complete: "
                f"{total_samples} total samples, "
                f"{'CONVERGED' if converged else 'NOT CONVERGED'}"
            )

        # =============================================================
        # PHASE 4: EXPLICIT ARTIFACT PERSISTENCE
        # Mirrors Step 2b Phase 4. Ensures .nc on disk reflects
        # the FULL accumulated posterior (initial + all extensions),
        # not just the last model.sample() auto-save.
        # =============================================================
        try:
            infdata_final = model.to_infdata(
                loglike=False, ppc=False
            )
            nc_path = f"{save_prefix}.nc"
            infdata_final.to_netcdf(nc_path)
            self.logger.info(
                f"    Accumulated InferenceData saved: "
                f"{Path(nc_path).name} "
                f"({total_samples} total samples)"
            )
        except Exception as e:
            self.logger.warning(
                f"    Phase 4 .nc persistence failed: {e}. "
                f"On-disk .nc may reflect only last extension."
            )

        try:
            hddm_path = f"{save_prefix}.hddm"
            model.save(hddm_path)
            self.logger.info(
                f"    Model object saved: "
                f"{Path(hddm_path).name}"
            )
        except Exception as e:
            self.logger.warning(
                f"    Phase 4 .hddm persistence failed: {e}."
            )

        del model, infdata
        gc.collect()

        return (summary_df, converged,
                float(metrics["f_rhat"]), metrics)

    # -----------------------------------------------------------------
    # SINGLE-ITERATION RECOVERY METRICS
    # With scale-aligned comparison (physical scale)
    # -----------------------------------------------------------------
    def compute_iteration_metrics(
        self,
        group_truth: Dict[str, float],
        summary_df: pd.DataFrame,
        iteration: int,
        mode: str,
        converged: bool,
        max_rhat: float,
        metrics: Dict[str, float]
    ) -> List[Dict]:
        """
        Computes per-parameter recovery metrics for a single
        iteration: Bias, Squared Error, Coverage, HDI Width.

        Ground-truth and recovered values are compared on the physical
        parameter scale. For v/a/t the generative and reported scales
        coincide (identity link), so no conversion is applied; the z
        intercept is mapped from the logit scale back to a probability
        with the inverse link before comparison. Biases are thus in
        physical units (seconds for t, threshold units for a, probability
        for z).
        """
        records = []

        for param, gt_lp in group_truth.items():
            if param not in summary_df.index:
                continue

            rec_row = summary_df.loc[param]
            rec_mean = float(rec_row['mean'])
            hdi_low = float(rec_row['hdi_3%'])
            hdi_high = float(rec_row['hdi_97%'])

            family = (
                param.split('_')[0] if '_' in param else 'other'
            )
            is_intercept = 'Intercept' in param

            # Convert GT to comparison scale.
            # Intercepts: LP → physical (to match refit summary)
            # Contrasts & v: already in same scale, no conversion
            gt_compare = self._apply_link_and_clip(
                family, gt_lp
            ) if (is_intercept and family == 'z') else gt_lp

            bias = rec_mean - gt_compare
            is_covered = hdi_low <= gt_compare <= hdi_high

            param_type = (
                'Intercept'
                if is_intercept
                else 'ConditionEffect'
            )

            records.append({
                'pipeline_hash': self.active_hash,
                'mode': mode,
                'iteration': iteration,
                'Parameter': param,
                'Family': family,
                'Type': param_type,
                'Ground_Truth': gt_compare,
                'Recovered_Mean': rec_mean,
                'Bias': bias,
                'Abs_Bias': np.abs(bias),
                'Sq_Error': bias ** 2,
                'HDI_3': hdi_low,
                'HDI_97': hdi_high,
                'HDI_Width': hdi_high - hdi_low,
                'Coverage': int(is_covered),
                'Refit_Converged': converged,
                'Refit_Max_Rhat': max_rhat,
                'Refit_F_ESS_Bulk': metrics.get(
                    'f_bulk', np.nan
                ),
                'Refit_F_ESS_Tail': metrics.get(
                    'f_tail', np.nan
                ),
                'Refit_N_Rhat': metrics.get(
                    'n_rhat', np.nan
                )
            })

        return records

    # -----------------------------------------------------------------
    # SUBJECT-LEVEL INTERCEPT RECOVERY
    # -----------------------------------------------------------------
    def compute_subject_intercept_recovery(
        self,
        subject_truths: Dict[str, Dict[str, Dict[str, float]]],
        summary_df: pd.DataFrame,
        iteration: int,
        mode: str,
        converged: bool
    ) -> List[Dict]:
        """
        Evaluates recovery of the subject-level random intercepts that the
        hierarchical model estimates under group_only_regressors=True.

        Ground truth for subject s and family p is the physical-scale
        baseline-condition value subject_truths[s][baseline][p]; given the
        shared-deviation generation this is that subject's random intercept.
        The recovered counterpart is the posterior mean of the subject node
        ('{p}_Intercept_subj.{s}' for regression families, '{p}_subj.{s}'
        otherwise).

        Comparison is on the physical scale: exact for v/a/t (identity
        link); for z the posterior-summary convention used for the
        group-level z intercept is reused (no additional transform). The
        primary diagnostic is the across-subject correlation, computed in
        export_subject_recovery_summary, rather than interval coverage.
        """
        records = []
        baseline = CFG.baseline_condition

        for subj, by_emo in subject_truths.items():
            if baseline not in by_emo:
                continue
            for p in ['v', 'a', 't', 'z']:
                true_phys = by_emo[baseline].get(p)
                if true_phys is None:
                    continue

                # Resolve the subject node name (regression vs plain param)
                candidates = [
                    f"{p}_Intercept_subj.{subj}",
                    f"{p}_subj.{subj}",
                ]
                node = next(
                    (c for c in candidates if c in summary_df.index),
                    None
                )
                if node is None:
                    continue

                records.append({
                    'pipeline_hash': self.active_hash,
                    'mode': mode,
                    'iteration': iteration,
                    'subj_idx': subj,
                    'Family': p,
                    'True_Subject_Intercept': float(true_phys),
                    'Recovered_Subject_Mean': float(
                        summary_df.loc[node, 'mean']
                    ),
                    'Refit_Converged': converged,
                })

        return records

    # -----------------------------------------------------------------
    # INCREMENTAL PERSISTENCE
    # -----------------------------------------------------------------
    @staticmethod
    def _append_records_to_csv(
        records: List[Dict], csv_path: Path
    ):
        """
        Atomically appends records to a CSV file.
        Creates the file with header on first write.
        """
        df_new = pd.DataFrame(records)
        if csv_path.exists():
            df_new.to_csv(
                csv_path, mode='a', header=False, index=False
            )
        else:
            df_new.to_csv(csv_path, index=False)

    # -----------------------------------------------------------------
    # PUBLICATION-READY AGGREGATE VISUALIZATION
    # -----------------------------------------------------------------
    def render_aggregate_diagnostics(self, mode: str):
        """
        Constructs visualizations from ALL converged iterations:
        1. Identity scatter (Ground Truth vs Recovered Mean)
           with marginal distributions.
        2. Coverage rate bar chart per parameter family.
        3. Bias distribution violin per parameter family.
        """
        csv_path = (
            PATHS['recovery']
            / f"recovery_all_iterations_"
              f"{self.target_model}_{mode}.csv"
        )
        if not csv_path.exists():
            self.logger.warning(
                f"  [{mode}] No iteration data found. "
                f"Visualization skipped."
            )
            return

        df = pd.read_csv(csv_path)

        # Filter to converged iterations only
        if 'Refit_Converged' in df.columns:
            n_total = df['iteration'].nunique()
            df_conv = df[df['Refit_Converged'] == True]
            n_conv = df_conv['iteration'].nunique()
            self.logger.info(
                f"  [{mode}] Using {n_conv}/{n_total} "
                f"converged iterations for visualization."
            )
        else:
            df_conv = df

        if df_conv.empty:
            self.logger.warning(
                f"  [{mode}] No converged iterations. "
                f"Visualization skipped."
            )
            return

        title_prefix = (
            "Posterior-Anchored"
            if mode == 'posterior'
            else "Prior-Predictive"
        )

        pal = {
            'v': OKABE_ITO[0], 'a': OKABE_ITO[1],
            't': OKABE_ITO[2], 'z': OKABE_ITO[6]
        }

        # --- Plot 1: Identity Scatter (aggregated) ---
        families = df_conv['Family'].unique()
        n_fam = max(1, len(families))
        fig, axes = plt.subplots(
            1, n_fam, figsize=(5 * n_fam, 5), squeeze=False
        )
        axes = axes.flatten()

        for ax, fam in zip(axes, families):
            fam_df = df_conv[df_conv['Family'] == fam]
            color = pal.get(fam, '#333333')

            ax.scatter(
                fam_df['Ground_Truth'],
                fam_df['Recovered_Mean'],
                alpha=0.3, s=20, color=color, edgecolors='none'
            )

            all_vals = pd.concat([
                fam_df['Ground_Truth'],
                fam_df['Recovered_Mean']
            ])
            margin = max(
                0.05, (all_vals.max() - all_vals.min()) * 0.1
            )
            lims = [
                all_vals.min() - margin,
                all_vals.max() + margin
            ]
            ax.plot(lims, lims, 'k--', alpha=0.5, zorder=0)
            ax.set_xlim(lims)
            ax.set_ylim(lims)

            if len(fam_df) >= 3:
                r_val, _ = stats.pearsonr(
                    fam_df['Ground_Truth'],
                    fam_df['Recovered_Mean']
                )
                rmse = float(
                    np.sqrt(fam_df['Sq_Error'].mean())
                )
                ax.set_title(
                    f"{fam.upper()} (r={r_val:.2f}, "
                    f"RMSE={rmse:.3f})",
                    fontweight='bold'
                )
            else:
                ax.set_title(
                    f"{fam.upper()}", fontweight='bold'
                )

            ax.set_xlabel("Ground Truth")
            ax.set_ylabel("Recovered Mean")

        plt.suptitle(
            f"{title_prefix} Recovery (N="
            f"{df_conv['iteration'].nunique()} iterations): "
            f"{self.target_model.upper()}",
            y=1.05, fontweight='bold'
        )
        sns.despine(trim=True)
        plt.tight_layout()
        plt.savefig(
            PATHS['figures_supp']
            / f"recovery_scatter_aggregate_"
              f"{self.target_model}_{mode}.pdf",
            dpi=300, bbox_inches='tight'
        )
        plt.close(fig)

        # --- Plot 2: Coverage Rate per Family ---
        coverage_agg = df_conv.groupby('Family').agg(
            Coverage_Rate=('Coverage', 'mean'),
            N=('Coverage', 'count')
        ).reset_index()

        fig, ax = plt.subplots(figsize=(6, 4))
        bars = ax.bar(
            coverage_agg['Family'].str.upper(),
            coverage_agg['Coverage_Rate'],
            color=[
                pal.get(f, '#999999')
                for f in coverage_agg['Family']
            ],
            alpha=0.8, edgecolor='black', linewidth=0.5
        )
        ax.axhline(
            0.94, color='red', linestyle='--', linewidth=1.5,
            label='Nominal 94% Coverage'
        )
        ax.set_ylabel('Empirical Coverage Rate')
        ax.set_title(
            f"{title_prefix}: 94% HDI Coverage",
            fontweight='bold'
        )
        ax.set_ylim(0, 1.05)
        ax.legend(fontsize=10)

        # Annotate percentages
        for bar, rate in zip(
            bars, coverage_agg['Coverage_Rate']
        ):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.02,
                f"{rate:.0%}",
                ha='center', fontsize=11, fontweight='bold'
            )

        sns.despine(trim=True)
        plt.tight_layout()
        plt.savefig(
            PATHS['figures_supp']
            / f"recovery_coverage_bar_"
              f"{self.target_model}_{mode}.pdf",
            dpi=300, bbox_inches='tight'
        )
        plt.close(fig)

        # --- Plot 3: Bias Distribution per Family ---
        fig, ax = plt.subplots(figsize=(7, 5))
        sns.violinplot(
            x='Family', y='Bias', data=df_conv,
            palette=pal, inner='box', cut=0, ax=ax,
            alpha=0.6, order=sorted(families)
        )
        ax.axhline(
            0, color='black', linestyle='--',
            linewidth=1.5, alpha=0.7
        )
        ax.set_title(
            f"{title_prefix}: Bias Distribution",
            fontweight='bold'
        )
        ax.set_ylabel('Bias (Recovered - Truth)')
        ax.set_xlabel('Parameter Family')
        sns.despine(trim=True)
        plt.tight_layout()
        plt.savefig(
            PATHS['figures_supp']
            / f"recovery_bias_violin_"
              f"{self.target_model}_{mode}.pdf",
            dpi=300, bbox_inches='tight'
        )
        plt.close(fig)

        self.logger.info(
            f"  [{mode}] Aggregate visualizations exported."
        )

    # -----------------------------------------------------------------
    # AGGREGATE SUMMARY TABLE
    # -----------------------------------------------------------------
    def export_aggregate_summary(self, mode: str):
        """
        Computes and exports aggregate recovery metrics across
        all converged iterations.
        """
        csv_path = (
            PATHS['recovery']
            / f"recovery_all_iterations_"
              f"{self.target_model}_{mode}.csv"
        )
        if not csv_path.exists():
            return

        df = pd.read_csv(csv_path)
        if 'Refit_Converged' in df.columns:
            df = df[df['Refit_Converged'] == True]

        if df.empty:
            return

        agg = df.groupby(['Family', 'Type']).agg(
            N_Iterations=('iteration', 'nunique'),
            N_Params=('Parameter', 'nunique'),
            RMSE=('Sq_Error', lambda x: np.sqrt(x.mean())),
            Mean_Abs_Bias=('Abs_Bias', 'mean'),
            Mean_HDI_Width=('HDI_Width', 'mean'),
            Coverage_Rate=('Coverage', 'mean')
        ).reset_index()

        agg_path = (
            PATHS['tables_supp']
            / f"recovery_aggregate_summary_"
              f"{self.target_model}_{mode}.csv"
        )
        agg.to_csv(agg_path, index=False)

        # Global correlation
        if len(df) >= 3:
            r_val, p_val = stats.pearsonr(
                df['Ground_Truth'], df['Recovered_Mean']
            )
            rmse_global = float(
                np.sqrt(df['Sq_Error'].mean())
            )
            self.logger.info(
                f"  [{mode}] Global: r={r_val:.3f} "
                f"(p={p_val:.2e}), RMSE={rmse_global:.4f}"
            )

        self.logger.info(f"\n{agg.to_string(index=False)}")

    # -----------------------------------------------------------------
    # SUBJECT-LEVEL INTERCEPT RECOVERY SUMMARY + FIGURE
    # -----------------------------------------------------------------
    def export_subject_recovery_summary(self, mode: str):
        """
        Aggregates subject-level intercept recovery across all converged
        iterations: per-family across-subject Pearson correlation, OLS
        slope, and RMSE between the true and recovered subject intercepts
        (pooled over subjects and iterations). Emits a summary table and an
        identity scatter (true vs recovered) per parameter family.

        The across-subject correlation indexes whether between-subject
        differences in the baseline parameters are recovered — the
        complement to the group-level focal-parameter diagnostics.
        """
        subj_csv = (
            PATHS['recovery']
            / f"recovery_subject_pairs_"
              f"{self.target_model}_{mode}.csv"
        )
        if not subj_csv.exists():
            self.logger.warning(
                f"  [{mode}] No subject-level recovery data. "
                f"Subject summary skipped."
            )
            return

        df = pd.read_csv(subj_csv)
        if 'Refit_Converged' in df.columns:
            df = df[df['Refit_Converged'] == True]
        if df.empty:
            self.logger.warning(
                f"  [{mode}] No converged subject-level data."
            )
            return

        rows = []
        for fam, g in df.groupby('Family'):
            t = g['True_Subject_Intercept'].values
            r = g['Recovered_Subject_Mean'].values
            if len(t) < 3:
                continue
            rows.append({
                'Family': fam,
                'N_Pairs': int(len(g)),
                'N_Subjects': int(g['subj_idx'].nunique()),
                'N_Iterations': int(g['iteration'].nunique()),
                'Pearson_r': float(np.corrcoef(t, r)[0, 1]),
                'OLS_Slope': float(np.polyfit(t, r, 1)[0]),
                'RMSE': float(np.sqrt(np.mean((r - t) ** 2))),
            })
        out = pd.DataFrame(rows)
        out_path = (
            PATHS['tables_supp']
            / f"recovery_subject_intercepts_"
              f"{self.target_model}_{mode}.csv"
        )
        out.to_csv(out_path, index=False)
        self.logger.info(
            f"  [{mode}] Subject-level intercept recovery:\n"
            f"{out.to_string(index=False)}"
        )

        # Identity scatter per family (true vs recovered subject intercept)
        title_prefix = (
            "Posterior-Anchored"
            if mode == 'posterior'
            else "Prior-Predictive"
        )
        pal = {
            'v': OKABE_ITO[0], 'a': OKABE_ITO[1],
            't': OKABE_ITO[2], 'z': OKABE_ITO[6]
        }
        families = sorted(df['Family'].unique())
        n_fam = max(1, len(families))
        fig, axes = plt.subplots(
            1, n_fam, figsize=(5 * n_fam, 5), squeeze=False
        )
        axes = axes.flatten()
        for ax, fam in zip(axes, families):
            fam_df = df[df['Family'] == fam]
            color = pal.get(fam, '#333333')
            ax.scatter(
                fam_df['True_Subject_Intercept'],
                fam_df['Recovered_Subject_Mean'],
                alpha=0.3, s=20, color=color, edgecolors='none'
            )
            all_vals = pd.concat([
                fam_df['True_Subject_Intercept'],
                fam_df['Recovered_Subject_Mean']
            ])
            margin = max(
                0.05, (all_vals.max() - all_vals.min()) * 0.1
            )
            lims = [all_vals.min() - margin, all_vals.max() + margin]
            ax.plot(lims, lims, 'k--', alpha=0.5, zorder=0)
            ax.set_xlim(lims)
            ax.set_ylim(lims)
            if len(fam_df) >= 3:
                r_val = float(np.corrcoef(
                    fam_df['True_Subject_Intercept'],
                    fam_df['Recovered_Subject_Mean']
                )[0, 1])
                ax.set_title(
                    f"{fam.upper()} (r={r_val:.2f})",
                    fontweight='bold'
                )
            else:
                ax.set_title(f"{fam.upper()}", fontweight='bold')
            ax.set_xlabel("True Subject Intercept")
            ax.set_ylabel("Recovered Subject Mean")
        plt.suptitle(
            f"{title_prefix} Subject-Level Intercept Recovery: "
            f"{self.target_model.upper()}",
            y=1.05, fontweight='bold'
        )
        sns.despine(trim=True)
        plt.tight_layout()
        plt.savefig(
            PATHS['figures_supp']
            / f"recovery_subject_scatter_"
              f"{self.target_model}_{mode}.pdf",
            dpi=300, bbox_inches='tight'
        )
        plt.close(fig)
        self.logger.info(
            f"  [{mode}] Subject-level recovery figure exported."
        )

    # -----------------------------------------------------------------
    # MASTER ITERATION LOOP
    # -----------------------------------------------------------------
    def run_mode(self, mode: str):
        """
        Executes N iterations of recovery for a given mode.

        Safety mechanisms:
          - Memory headroom check before each iteration
          - Consecutive failure guard (MemoryError, numerical)
          - Incremental CSV persistence after each iteration
          - Checkpoint resume on restart
        """
        self.logger.info(f"\n{'*'*60}")
        self.logger.info(
            f"RECOVERY MODE: {mode.upper()} "
            f"({self.n_iterations} iterations)"
        )
        self.logger.info(f"{'*'*60}")

        csv_path = (
            PATHS['recovery']
            / f"recovery_all_iterations_"
              f"{self.target_model}_{mode}.csv"
        )
        subj_csv_path = (
            PATHS['recovery']
            / f"recovery_subject_pairs_"
              f"{self.target_model}_{mode}.csv"
        )

        # Check for existing results (resume support)
        # Robust CSV resume: handles corrupted files
        # from mid-write crashes (e.g., power loss during
        # _append_records_to_csv). If the CSV is unreadable,
        # it is backed up and a fresh run begins.
        completed_iters = set()
        if csv_path.exists():
            try:
                existing = pd.read_csv(csv_path)
                if 'iteration' in existing.columns:
                    completed_iters = set(
                        existing['iteration'].unique()
                    )
                    self.logger.info(
                        f"  Resume: {len(completed_iters)} "
                        f"iterations already completed."
                    )
            except Exception as e:
                backup = csv_path.with_suffix('.csv.bak')
                csv_path.rename(backup)
                self.logger.warning(
                    f"  CSV corrupted ({e}). "
                    f"Backed up to {backup.name}. "
                    f"Starting fresh."
                )

        consecutive_failures = 0

        for iteration in range(self.n_iterations):
            if iteration in completed_iters:
                continue

            self.logger.info(
                f"\n  --- Iteration {iteration + 1}/"
                f"{self.n_iterations} (mode={mode}) ---"
            )

            # Memory check
            try:
                check_memory_headroom(logger=self.logger)
            except MemoryError:
                self.logger.error(
                    "  Memory insufficient. "
                    "Terminating recovery."
                )
                break

            try:
                t_start = time.time()

                # Phase 1: Generate ground truth + synthetic data
                group_truth, subject_truths = (
                    self.establish_ground_truth(mode, iteration)
                )

                synth_df = self.generate_synthetic_data(
                    subject_truths, iteration, mode
                )

                # Phase 2: Refit with stratified convergence
                # and adaptive sampling (runs to completion)
                summary_df, converged, max_rhat, metrics = (
                    self.execute_recovery_refit(
                        synth_df, iteration, mode
                    )
                )

                # Phase 3: Compute metrics
                if summary_df is not None:
                    records = self.compute_iteration_metrics(
                        group_truth, summary_df,
                        iteration, mode,
                        converged, max_rhat,
                        metrics
                    )

                    # Incremental persistence
                    if records:
                        self._append_records_to_csv(
                            records, csv_path
                        )

                    # Subject-level intercept recovery (incremental)
                    subj_records = (
                        self.compute_subject_intercept_recovery(
                            subject_truths, summary_df,
                            iteration, mode, converged
                        )
                    )
                    if subj_records:
                        self._append_records_to_csv(
                            subj_records, subj_csv_path
                        )

                elapsed = (time.time() - t_start) / 60
                status = (
                    'CONVERGED' if converged
                    else f'NOT CONVERGED (R-hat={max_rhat:.3f})'
                )
                self.logger.info(
                    f"  Iteration {iteration + 1}: {status} "
                    f"({elapsed:.1f} min)"
                )

                consecutive_failures = 0

            except Exception as e:
                consecutive_failures += 1
                self.logger.warning(
                    f"  Iteration {iteration + 1}: EXCEPTION "
                    f"({type(e).__name__}: {e}). "
                    f"Consecutive failures: "
                    f"{consecutive_failures}/"
                    f"{MAX_CONSECUTIVE_FAILURES}"
                )
                self.logger.warning(traceback.format_exc())

            finally:
                gc.collect()

            # Consecutive failure guard
            if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                self.logger.error(
                    f"  {MAX_CONSECUTIVE_FAILURES} consecutive "
                    f"failures reached. Terminating {mode} mode."
                )
                break

    # -----------------------------------------------------------------
    # FULL PIPELINE
    # -----------------------------------------------------------------
    def run_full_pipeline(self):
        """
        Orchestrates both posterior-anchored and prior-predictive
        recovery protocols with aggregate reporting for the single
        specified target model.
        """
        self.logger.info(f"\n{'#'*70}")
        self.logger.info(
            f"RECOVERY TARGET: [{self.target_model.upper()}]"
        )
        self.logger.info(f"{'#'*70}")

        for mode in ['posterior', 'prior']:
            self.run_mode(mode)
            self.export_aggregate_summary(mode)
            self.render_aggregate_diagnostics(mode)
            self.export_subject_recovery_summary(mode)

        self.logger.info(f"\n{'='*70}")
        self.logger.info(
            "PARAMETER RECOVERY COMPLETED"
        )
        self.logger.info(
            f"Model: [{self.target_model.upper()}]"
        )
        self.logger.info(f"{'='*70}")


# =============================================================================
# PIPELINE EXECUTION ENTRY POINT
# =============================================================================
# Usage:
#   engine = ParameterRecoveryEngine(target_model='va')
#   engine.run_full_pipeline()
#
# Extension (after initial 30 complete, add 10 more):
#   engine = ParameterRecoveryEngine(target_model='va', n_iterations=40)
#   engine.run_full_pipeline()
#   # Automatically skips iterations 0-29, runs only 30-39.
#
# Before FIRST run, ensure that:
#   1. Step 2a has been executed (hddm_config.py exists)
#   2. Step 2b has fitted the target model (hddm_va.nc exists)
#   3. Step 4 has produced the audit trail (final_model_selection_audit.csv)
#   4. OLD recovery CSV files have been DELETED or RENAMED to avoid
#      contamination from the pre-fix scale-mismatched results:
#        rm recovery_all_iterations_va_posterior.csv
#        rm recovery_all_iterations_va_prior.csv
#        rm recovery_subject_pairs_va_posterior.csv
#        rm recovery_subject_pairs_va_prior.csv
# =============================================================================

# ============================================================
# PARAMETER RECOVERY -- execution record (which models, and why)
# ------------------------------------------------------------
# Step 4's DIC funnel auto-selected `vaz` as winner, but `va` was
# the a-priori reported model (parsimony + consistency with E1).
# Recovery for `va` was therefore run FIRST and is COMPLETE
# (see recovery/ and tables_supp/recovery_aggregate_summary_va_*).
#
# To adjudicate `va` vs `vaz` rigorously we now ALSO run recovery
# for `vaz`, to test whether its z-by-emotion contrasts are
# identifiable/recoverable (vaz shows a v-z posterior correlation
# ~ -0.6). If vaz's z ConditionEffect fails to recover, that is the
# decisive evidence for reporting `va` over the DIC-preferred `vaz`.
# ============================================================

# (1) va recovery -- ALREADY COMPLETED; kept here for the record.
#     Re-enable only to regenerate va recovery (resume-safe: skips
#     iterations already on disk).
# engine_va = ParameterRecoveryEngine(target_model='va')
# engine_va.run_full_pipeline()

# (2) vaz recovery -- identifiability check for the DIC winner.
try:
    engine = ParameterRecoveryEngine(target_model='va')
    engine.run_full_pipeline()
except Exception as e:
    print(f"\nCRITICAL FAILURE: {e}")
    import traceback
    traceback.print_exc()