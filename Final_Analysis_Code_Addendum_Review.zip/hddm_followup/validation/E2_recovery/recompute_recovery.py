"""Recompute the authorized E2 iteration-19 rescue; never fit or simulate data."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import logging
import sys
from types import SimpleNamespace
from typing import Dict, List
import arviz as az
import numpy as np
import pandas as pd
from scipy.special import expit, logit
from scipy import stats

OUT = Path('/output')
SOURCE = Path('/e2/results_hddm_final')
RUN = Path('/original/E2')
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

sys.path.insert(0, '/e2')
runner_path = Path('/original/code/run_authorized_refit.py')
assert sha(runner_path) == '78455c3b940fc116f69f518ce7bbe75f31f55d9d9426cb53d051ce1d5d47793d'
spec = importlib.util.spec_from_file_location('runner', runner_path)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
manifest = json.loads((RUN/'manifest.json').read_text())
assessment = json.loads((RUN/'attempt_1_8000/assessment.json').read_text())
posterior = RUN/'attempt_1_8000/verified_posterior.nc'
assert sha(posterior) == assessment['sha256'] == '2f76b44c563a13de49b0f154a78ca4024dbcc7132a6a83e5caf8c196e2a25ab6'
assert sha(RUN/'analysis_data.csv') == manifest['analysis_csv_sha256']
source_model = SOURCE/'recovery/recovery_va_posterior_iter19.hddm'
assert sha(source_model) == manifest['source_sha256']
saved = runner.read_saved_state(source_model)
frame = pd.read_csv(RUN/'analysis_data.csv', dtype={'subj_idx':str})
pd.testing.assert_frame_equal(saved.data.reset_index(drop=True), frame, check_exact=False, atol=1e-12, rtol=1e-12)
idata = az.from_netcdf(posterior)
assert dict(idata.posterior.sizes) == {'chain':4, 'draw':3000}
assert all(np.isfinite(v.values).all() for v in idata.posterior.data_vars.values())
summary95, metrics, passed = runner.metrics_of(idata, manifest['criteria'])
assert passed
pd.testing.assert_frame_equal(summary95, pd.read_csv(RUN/'attempt_1_8000/posterior_summary.csv', index_col=0), atol=1e-6, rtol=1e-8)
assert idata.posterior.equals(az.from_netcdf(RUN/'attempt_1_8000/refit.nc').posterior)
# Recovery uses nominal 94% HDIs and four-decimal summary precision, exactly as Step 6.
summary = az.summary(idata, hdi_prob=.94, round_to=4)
summary.to_csv(OUT/'iteration19_summary_94.csv')

# Compile only the original pure metric/aggregation methods. No notebook setup,
# model construction, fitting, simulation, plotting, or input writes are executed.
notebook = Path('/e2/Final_vazt-Unfair_Grouplevel_InformativePr_E2.ipynb')
cell = ''.join(json.loads(notebook.read_text())['cells'][13]['source'])
assert cell == (OUT/'notebook_cell_13.py').read_text()
tree = ast.parse(cell)
original_class = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'ParameterRecoveryEngine')
names = {'_apply_link_and_clip','compute_iteration_metrics','compute_subject_intercept_recovery','export_aggregate_summary','export_subject_recovery_summary'}
methods = [n for n in original_class.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(methods) == 5
for n in methods:
    if n.name == 'export_subject_recovery_summary':
        plot_start = next(i for i,b in enumerate(n.body) if isinstance(b,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='title_prefix' for t in b.targets))
        n.body = n.body[:plot_start]
safe_class = ast.ClassDef(name='MetricsOnly', bases=[], keywords=[], body=methods, decorator_list=[])
safe = ast.fix_missing_locations(ast.Module(body=[safe_class], type_ignores=[]))
(OUT/'metric_methods_extracted.py').write_text(ast.unparse(safe)+'\n')
CFG = SimpleNamespace(baseline_condition='neu')
PATHS = {}
exec(compile(safe, '<canonical Step 6 metric methods>', 'exec'), globals())
engine = MetricsOnly()
engine.target_model = 'va'
engine.logger = logging.getLogger('recovery_validation')
group_path = SOURCE/'recovery/recovery_all_iterations_va_posterior.csv'
subject_path = SOURCE/'recovery/recovery_subject_pairs_va_posterior.csv'
group = pd.read_csv(group_path)
subject = pd.read_csv(subject_path, dtype={'subj_idx':str})
assert len(group)==240 and len(subject)==2400
assert set(group.iteration)==set(range(20))
assert set(group.loc[~group.Refit_Converged,'iteration'])=={19}
assert set(subject.loc[~subject.Refit_Converged,'iteration'])=={19}
engine.active_hash = group.pipeline_hash.unique().item()
g19 = group[group.iteration==19].copy()
s19 = subject[subject.iteration==19].copy()
truth = g19.set_index('Parameter').Ground_Truth.to_dict()
truth['z_Intercept'] = logit(truth['z_Intercept'])
subject_truth = {}
for sid, f in frame.groupby('subj_idx'):
    baseline = f[f.emotion=='neu']
    assert len(baseline)>0
    assert all(baseline[p+'_true'].nunique()==1 for p in ['v','a','t','z'])
    subject_truth[sid] = {'neu':{p:float(baseline[p+'_true'].iloc[0]) for p in ['v','a','t','z']}}
for _, row in s19.iterrows():
    assert np.isclose(row.True_Subject_Intercept, subject_truth[row.subj_idx]['neu'][row.Family], atol=1e-12, rtol=1e-12)
newg = pd.DataFrame(engine.compute_iteration_metrics(truth, summary, 19, 'posterior', True, metrics['f_rhat'], metrics))
news = pd.DataFrame(engine.compute_subject_intercept_recovery(subject_truth, summary, 19, 'posterior', True))
pd.testing.assert_frame_equal(newg[['Parameter','Ground_Truth']].reset_index(drop=True), g19[['Parameter','Ground_Truth']].reset_index(drop=True), check_exact=False, atol=1e-15, rtol=1e-15)
# Preserve the archived literal truths; the z logit/expit round trip can differ at machine epsilon.
newg['Ground_Truth'] = newg.Parameter.map(g19.set_index('Parameter').Ground_Truth)
newg['Bias'] = newg.Recovered_Mean-newg.Ground_Truth
newg['Abs_Bias'] = newg.Bias.abs(); newg['Sq_Error'] = newg.Bias**2
updated_group = pd.concat([group[group.iteration!=19], newg], ignore_index=True)
updated_subject = pd.concat([subject[subject.iteration!=19], news], ignore_index=True)
pd.testing.assert_frame_equal(updated_group[updated_group.iteration!=19].reset_index(drop=True),group[group.iteration!=19].reset_index(drop=True))
pd.testing.assert_frame_equal(updated_subject[updated_subject.iteration!=19].reset_index(drop=True),subject[subject.iteration!=19].reset_index(drop=True))

for label, g, s in [('original',group,subject),('updated',updated_group,updated_subject)]:
    base=OUT/label
    PATHS.update(recovery=base/'recovery',tables_supp=base/'tables_supp')
    for p in PATHS.values(): p.mkdir(parents=True,exist_ok=True)
    g.to_csv(PATHS['recovery']/group_path.name,index=False)
    s.to_csv(PATHS['recovery']/subject_path.name,index=False)
    engine.export_aggregate_summary('posterior')
    engine.export_subject_recovery_summary('posterior')
    correlations=[]
    for fam,x in g[g.Refit_Converged & (g.Type=='ConditionEffect')].groupby('Family'):
        correlations.append({'Family':fam,'N_Pairs':len(x),'N_Iterations':x.iteration.nunique(),'Pearson_r':np.corrcoef(x.Ground_Truth,x.Recovered_Mean)[0,1]})
    pd.DataFrame(correlations).to_csv(base/'group_contrast_correlations.csv',index=False)
    if label=='original':
        for p in PATHS['tables_supp'].glob('*.csv'):
            pd.testing.assert_frame_equal(pd.read_csv(p),pd.read_csv(SOURCE/'tables_supp'/p.name),atol=1e-12,rtol=1e-12)

newg.to_csv(OUT/'iteration19_group_updated.csv',index=False)
news.to_csv(OUT/'iteration19_subject_updated.csv',index=False)
changes=[]
for name in ['recovery_aggregate_summary_va_posterior.csv','recovery_subject_intercepts_va_posterior.csv']:
    keys=['Family','Type'] if 'aggregate' in name else ['Family']
    old=pd.read_csv(OUT/'original/tables_supp'/name).set_index(keys)
    new=pd.read_csv(OUT/'updated/tables_supp'/name).set_index(keys)
    for ix in old.index:
        for col in old.columns:
            changes.append({'table':name,'row':str(ix),'column':col,'old':old.loc[ix,col],'updated':new.loc[ix,col]})
pd.DataFrame(changes).to_csv(OUT/'aggregate_changes.csv',index=False)
inputs=[notebook,source_model,posterior,RUN/'analysis_data.csv',group_path,subject_path]
inputs+=list((SOURCE/'tables_supp').glob('recovery_*va_*.csv'))
receipt={'status':'ANALYZED','data_rows':len(frame),'subjects':frame.subj_idx.nunique(),'initial_passing_iterations':19,'updated_passing_iterations':20,'iterations_total':20,'replaced_iteration':19,'chains':4,'draws_per_chain':3000,'metrics':metrics,'criteria':manifest['criteria'],'recovery_hdi_probability':.94,'recovery_summary_decimals':4,'source_hashes':{str(p):sha(p) for p in inputs},'checks':['same saved synthetic frame including truths','archived subject truths match saved neutral rows','original aggregates exactly reproduced within 1e-12','only iteration19 replaced','group truths preserved','all posterior draws finite; summaries and native posterior match','no fitting or data generation'],'limitation':'Original process exited after posterior export at unsupported InferenceData.close; original failure records remain unchanged. Original first-pass 19/20 retained. Prior/broader track unchanged.'}
(OUT/'recovery_receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
