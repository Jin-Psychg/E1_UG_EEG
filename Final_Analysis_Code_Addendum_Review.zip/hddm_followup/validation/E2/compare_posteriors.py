"""Read-only comparison of primary, superseded, and newly verified E2 posteriors."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import arviz as az
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

out = Path('/output')
paths = {'primary':Path('/primary/results_hddm_final/models/hddm_va.nc'),
         'previous_sensitivity':Path('/previous/hddm_va_zero_accept.nc'),
         'new_sensitivity':Path('/new/attempt_1_8000/verified_posterior.nc')}
assert hashlib.sha256(paths['new_sensitivity'].read_bytes()).hexdigest() == 'e4c44444681074c5e09d2cae0d4f3d40dcc97fb8917580223fc0b50ece9c8093'
frames = {key:az.from_netcdf(path) for key,path in paths.items()}
summaries = {key:az.summary(data, hdi_prob=.95, round_to=6) for key,data in frames.items()}
cols = ['mean','sd','hdi_2.5%','hdi_97.5%','mcse_mean','ess_bulk','ess_tail','r_hat']
names = [name for name in summaries['new_sensitivity'].index
         if (name.startswith('v_C(') or name.startswith('a_C(')) and '_subj.' not in name]
assert len(names) == 8
original_comparison = pd.read_csv('/previous/contrast_comparison.csv').set_index('contrast_variable')
native_primary = pd.read_csv('/primary/results_hddm_final/audit/summary_va.csv', index_col=0)
native_new = pd.read_csv('/new/attempt_1_8000/posterior_summary.csv', index_col=0)
pd.testing.assert_frame_equal(summaries['new_sensitivity'],native_new,check_exact=False,atol=1e-6,rtol=1e-8)
native_old = pd.read_csv('/previous/posterior_summary.csv', index_col=0)
pd.testing.assert_frame_equal(summaries['previous_sensitivity'],native_old,check_exact=False,atol=1e-6,rtol=1e-8)
manifest=json.loads(Path('/new/manifest.json').read_text())
assert hashlib.sha256(Path('/primary/results_hddm_final/models/hddm_va.hddm').read_bytes()).hexdigest()==manifest['source_sha256']
assert hashlib.sha256(Path('/primary/hddm_config_values.json').read_bytes()).hexdigest()==manifest['config_sha256']
assert dict(frames['new_sensitivity'].posterior.sizes)=={'chain':4,'draw':3000}
primary_data=pd.read_csv('/primary/hddm_data_unfair.csv',dtype={'subj_idx':str})
new_data=pd.read_csv('/new/analysis_data.csv',dtype={'subj_idx':str});new_data['rt']=new_data.rt.abs()
previous_data=pd.read_csv('/previous/analysis_data.csv',dtype={'subj_idx':str})
pd.testing.assert_frame_equal(new_data,previous_data,check_exact=False,atol=1e-12,rtol=1e-12)
pd.testing.assert_frame_equal(primary_data.loc[~primary_data.subj_idx.isin(['1','22'])].reset_index(drop=True),new_data,check_exact=False,atol=1e-12,rtol=1e-12)
assert len(new_data)==10018 and new_data.subj_idx.nunique()==28

for name in names:
    for col, old_col in [('mean','primary_mean'),('hdi_2.5%','primary_hdi_low'),('hdi_97.5%','primary_hdi_high')]:
        assert abs(summaries['primary'].loc[name,col]-original_comparison.loc[name,old_col]) <= 1.1e-6
        assert abs(summaries['primary'].loc[name,col]-native_primary.loc[name,col]) <= .000051
rows = []
for name in names:
    row = {'parameter':name[0], 'contrast':name, 'reference':'neu'}
    for label,summary in summaries.items():
        for col in cols:
            row[f'{label}_{col}'] = float(summary.loc[name,col])
        lo,hi = summary.loc[name,['hdi_2.5%','hdi_97.5%']]
        row[f'{label}_hdi_excludes_zero'] = bool(lo>0 or hi<0)
    row['new_minus_primary_mean'] = row['new_sensitivity_mean']-row['primary_mean']
    row['new_minus_previous_mean'] = row['new_sensitivity_mean']-row['previous_sensitivity_mean']
    row['direction_preserved'] = bool(np.sign(row['new_sensitivity_mean']) == np.sign(row['primary_mean']))
    row['hdi_classification_preserved'] = row['new_sensitivity_hdi_excludes_zero'] == row['primary_hdi_excludes_zero']
    row['shift_in_primary_posterior_sd'] = abs(row['new_minus_primary_mean'])/row['primary_sd']
    rows.append(row)
comparison = pd.DataFrame(rows)
comparison.to_csv(out/'contrast_comparison.csv',index=False)

# Verify the explicitly reported Reward-minus-Disgust drift contrast from joint draws.
planned=[]
for label,data in frames.items():
    draws=(data.posterior["v_C(emotion, Treatment('neu'))[T.rew]"]-data.posterior["v_C(emotion, Treatment('neu'))[T.dis]"]).values
    interval=az.hdi(draws.reshape(-1),hdi_prob=.95)
    planned.append({'run':label,'contrast':'Reward minus Disgust','parameter':'v','mean':float(draws.mean()),'hdi_low':float(interval[0]),'hdi_high':float(interval[1])})
pd.DataFrame(planned).to_csv(out/'planned_contrast_comparison.csv',index=False)

for key,summary in summaries.items():
    summary.to_csv(out/f'{key}_summary_recomputed.csv')
diagnostics=[]
for label,summary in summaries.items():
    focal_names=[n for n in summary.index if '_subj.' not in n and not n.endswith('_std') and (n.endswith('_Intercept') or 'C(emotion' in n)]
    for category,subset in [('focal',summary.loc[focal_names]),('remaining',summary.drop(index=focal_names))]:
        diagnostics.append({'run':label,'category':category,'rhat_max':subset.r_hat.max(),
            'bulk_min':subset.ess_bulk.min(),'tail_min':subset.ess_tail.min(),
            'max_rhat_parameter':subset.r_hat.idxmax(),'min_bulk_parameter':subset.ess_bulk.idxmin()})
pd.DataFrame(diagnostics).to_csv(out/'diagnostic_comparison.csv',index=False)
targets=[r['max_rhat_parameter'] for r in diagnostics if r['run']=='previous_sensitivity']
worst=[row['max_rhat_parameter'] for row in diagnostics if row['run']=='new_sensitivity']
targets=list(dict.fromkeys(targets+worst))
subject_rows=[]
for name in targets:
    for label,summary in summaries.items():
        if name in summary.index:
            subject_rows.append({'parameter':name,'run':label,**summary.loc[name,cols].to_dict()})
pd.DataFrame(subject_rows).to_csv(out/'previously_problematic_and_current_worst.csv',index=False)
fig,axes=plt.subplots(len(targets),2,figsize=(15,3*len(targets)),squeeze=False)
for i,name in enumerate(targets):
    for j,label in enumerate(['previous_sensitivity','new_sensitivity']):
        values=frames[label].posterior[name].values
        for chain in range(values.shape[0]):
            axes[i,j].plot(values[chain],lw=.4,alpha=.7,label=f'Chain {chain+1}')
        axes[i,j].set_title(f'{label}: {name}',fontsize=9)
        axes[i,j].set_xlabel('Retained draw index')
        axes[i,j].set_ylabel('Parameter value')
axes[0,1].legend(fontsize=7,ncol=4)
fig.tight_layout()
fig.savefig(out/'trace_review.png',dpi=130)
plt.close(fig)
receipt={'source_sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths.values()},
 'posterior_dimensions':{label:dict(data.posterior.sizes) for label,data in frames.items()},
 'contrasts':len(rows),'all_directions_preserved':bool(comparison.direction_preserved.all()),
 'all_hdi_classifications_preserved':bool(comparison.hdi_classification_preserved.all()),
 'max_absolute_mean_change_by_parameter':comparison.groupby('parameter').new_minus_primary_mean.apply(lambda s:float(s.abs().max())).to_dict(),
 'scope':'Read-only saved-posterior comparison; no new sampling, data changes, or manuscript adoption.', 'model_and_config_hashes_match_manifest':True, 'new_and_previous_sensitivity_data_match_primary_exclusion':True, 'primary_participants':int(primary_data.subj_idx.nunique()),'primary_trials':len(primary_data),'sensitivity_participants':int(new_data.subj_idx.nunique()),'sensitivity_trials':len(new_data),
 'verification':'Recomputed new summary matches saved output; primary contrast summaries match prior six-decimal comparison and four-decimal canonical audit.'}
(out/'comparison_receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
print(comparison[['parameter','contrast','primary_mean','primary_hdi_2.5%','primary_hdi_97.5%','new_sensitivity_mean','new_sensitivity_hdi_2.5%','new_sensitivity_hdi_97.5%','hdi_classification_preserved']].to_string(index=False))
print(pd.DataFrame(subject_rows)[['parameter','run','r_hat','ess_bulk','ess_tail']].to_string(index=False))
